// Import standardized types from shared package for consistency
export { TransactionType, TransactionStatus, isGameTransaction, isTournamentTransaction } from '@ton-checkers/shared';

// Type aliases for backward compatibility (allows both enum and string literals)
export type TransactionTypeString = 
  | 'deposit' 
  | 'withdraw' 
  | 'stake' 
  | 'prize' 
  | 'fee'
  | 'tournament_entry'
  | 'tournament_prize'
  | 'tournament_refund'
  | 'tournament_creator_fee'
  | 'tournament_platform_fee'
  | 'platform_fee'
  | 'virtual_transfer';

export type TransactionStatusString = 
  | 'pending' 
  | 'processing'
  | 'completed' 
  | 'failed'
  | 'cancelled';

export interface Transaction {
  id: string;
  userId: string;
  type: TransactionTypeString;
  status: TransactionStatusString;
  amount: number;
  description?: string;
  hash?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface TransactionHistory {
  transactions: Transaction[];
  total: number;
}

export interface BalanceInfo {
  balance: string;
  available: string;
  locked: string;
}

export interface TransactionFilters {
  type?: TransactionTypeString;
  status?: TransactionStatusString;
  page?: number;
  limit?: number;
}

export interface StakeInfo {
  stakeTransaction: Transaction;
  feeTransaction: Transaction;
  totalAmount: number;
}

// WebSocket event payloads
export interface TransactionCreatedEvent {
  transaction: Transaction;
  type: TransactionTypeString;
  amount: number;
}

export interface TransactionCompletedEvent {
  transaction: Transaction;
  type: TransactionTypeString;
  hash: string;
}

export interface TransactionFailedEvent {
  transaction: Transaction;
  type: TransactionTypeString;
  reason: string;
}

export interface BalanceUpdatedEvent {
  balance: string;
  transaction?: Transaction;
}

// TON specific types
export interface DepositInstructions {
  address: string;
  amount: string;
  transactionId: string;
}

export interface WithdrawalRequest {
  amount: string;
  tonAddress: string;
}