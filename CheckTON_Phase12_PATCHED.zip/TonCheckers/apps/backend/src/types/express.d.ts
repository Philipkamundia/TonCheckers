declare namespace Express {
  interface User {
    id: string;
    walletAddress: string;
    isAdmin: boolean;
    role?: string;
    permissions?: string[];
  }
}

export interface AuthenticatedRequest extends Request {
  user: {
    id: string;
    walletAddress: string;
    isAdmin: boolean;
  };
}

export interface AdminRequest extends Request {
  user: {
    id: string;
    role: string;
    permissions: string[];
  };
}