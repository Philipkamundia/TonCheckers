export interface Player {
  id: string;
  username?: string;
  eloRating: number;
  // Add other player fields as needed
}