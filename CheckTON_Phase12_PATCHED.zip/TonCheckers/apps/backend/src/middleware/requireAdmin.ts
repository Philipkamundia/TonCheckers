/**
 * requireAdmin.ts — Admin authentication middleware (PRD §15)
 *
 * Admin identity is verified cryptographically:
 * - User must connect the treasury wallet
 * - Sign a challenge string with their wallet private key (Ed25519)
 * - Backend verifies the signature against the treasury wallet address
 *
 * Request must include:
 *   Authorization: Bearer <jwt>             (regular user JWT)
 *   X-Admin-Wallet:    <wallet-address>     (must match TREASURY_WALLET_ADDRESS)
 *   X-Admin-Signature: <base64-ed25519-sig> (signs the challenge)
 *   X-Admin-Challenge: <challenge-string>   (issued by /api/admin/challenge)
 *   X-Admin-State-Init: <base64-stateInit>  (for public key extraction)
 */
import crypto from 'crypto';
import { Request, Response, NextFunction } from 'express';
import { AppError } from './errorHandler.js';
import { logger } from '../utils/logger.js';

const TREASURY_WALLET = process.env.TREASURY_WALLET_ADDRESS?.toLowerCase();
const CHALLENGE_TTL_SECS = 300; // 5 minutes

export function requireAdmin(req: Request, _res: Response, next: NextFunction) {
  if (!TREASURY_WALLET) {
    logger.error('TREASURY_WALLET_ADDRESS not configured — admin access blocked');
    return next(new AppError(503, 'Admin access not configured', 'ADMIN_NOT_CONFIGURED'));
  }

  const adminWallet    = req.headers['x-admin-wallet']     as string | undefined;
  const adminSig       = req.headers['x-admin-signature']  as string | undefined;
  const adminChallenge = req.headers['x-admin-challenge']  as string | undefined;
  const adminStateInit = req.headers['x-admin-state-init'] as string | undefined;

  // 1. Wallet address must be present and match treasury wallet
  if (!adminWallet) {
    return next(new AppError(403, 'Admin wallet header required', 'FORBIDDEN'));
  }
  if (adminWallet.toLowerCase() !== TREASURY_WALLET) {
    logger.warn(`Admin access attempt with wrong wallet: ${adminWallet}`);
    return next(new AppError(403, 'Not authorised — treasury wallet required', 'FORBIDDEN'));
  }

  // 2. All required headers must be present
  if (!adminSig || !adminChallenge || !adminStateInit) {
    return next(new AppError(403, 'Admin signature, challenge, and stateInit required', 'FORBIDDEN'));
  }

  // 3. Verify challenge is recent (max 5 minutes)
  // Challenge format: "checkton-admin:{timestamp}"
  const parts     = adminChallenge.split(':');
  const timestamp = parseInt(parts[1] ?? '0', 10);
  const age       = Math.floor(Date.now() / 1000) - timestamp;

  if (isNaN(timestamp) || age > CHALLENGE_TTL_SECS || age < 0) {
    return next(new AppError(403, 'Admin challenge expired — request a new one', 'CHALLENGE_EXPIRED'));
  }

  // 4. Extract public key from stateInit and verify Ed25519 signature
  try {
    const stateInitBuf = Buffer.from(adminStateInit, 'base64');
    if (stateInitBuf.length < 38) {
      return next(new AppError(403, 'Invalid stateInit — too short', 'FORBIDDEN'));
    }

    // Standard WalletV4R2: 32-byte public key at bytes 6..38 of data cell
    const publicKey = stateInitBuf.slice(6, 38);

    const sigBuf = Buffer.from(adminSig, 'base64');
    if (sigBuf.length !== 64) {
      return next(new AppError(403, 'Invalid signature length', 'FORBIDDEN'));
    }

    // The signed payload is the challenge string itself
    const challengeBuf = Buffer.from(adminChallenge, 'utf8');

    const isValid = crypto.verify(
      null,
      challengeBuf,
      { key: publicKey, format: 'raw', type: 'public', dsaEncoding: 'ieee-p1363' } as crypto.KeyLike,
      sigBuf,
    );

    if (!isValid) {
      logger.warn(`Admin signature verification failed for wallet: ${adminWallet}`);
      return next(new AppError(403, 'Invalid admin signature', 'FORBIDDEN'));
    }
  } catch (err) {
    logger.error(`Admin signature verification error: ${(err as Error).message}`);
    return next(new AppError(403, 'Signature verification error', 'FORBIDDEN'));
  }

  logger.info(`Admin access granted: wallet=${adminWallet}`);
  next();
}

/** Generate a fresh admin challenge string */
export function generateAdminChallenge(): string {
  // Include random nonce to prevent precomputation attacks
  const nonce = crypto.randomBytes(8).toString('hex');
  return `checkton-admin:${Math.floor(Date.now() / 1000)}:${nonce}`;
}
