/**
 * SettlementService — Full post-game settlement
 *
 * PRD §12:
 *   Win:   Winner receives (Stake × 2) × 0.85 | Platform fee 15%
 *   Draw:  Both stakes returned, zero fee, zero ELO change
 *
 * PRD §13 post-game payload:
 *   winner, loser, ELO changes, full payout breakdown
 */
import pool from '../config/db.js';
import { multiplyRate, subtractTon } from '../utils/ton-math.js';
import { EloService } from './elo.service.js';
import { NotificationService } from './notification.service.js';
import { logger } from '../utils/logger.js';

const PLATFORM_FEE_PCT = 0.15; // used only as rate arg to multiplyRate (integer basis points internally)

export interface SettlementResult {
  gameId:       string;
  winnerId:     string;
  loserId:      string;
  stake:        string;
  prizePool:    string;
  platformFee:  string;
  winnerPayout: string;
  eloChanges: {
    winner: { before: number; after: number; delta: number };
    loser:  { before: number; after: number; delta: number };
  };
}

export interface DrawResult {
  gameId: string; player1Id: string; player2Id: string; stake: string;
}

export class SettlementService {

  /** PRD §12: (Stake × 2) × 0.85 — uses BigInt arithmetic, no float drift */
  static calculateWinPayout(stakeEach: string) {
    const prizePool   = multiplyRate(stakeEach, 2);        // stake * 2
    const platformFee = multiplyRate(prizePool, PLATFORM_FEE_PCT);
    const winnerPayout = subtractTon(prizePool, platformFee);
    return { prizePool, platformFee, winnerPayout };
  }

  /**
   * Full win settlement — single DB transaction:
   * ELO update, balance settlement, stats update, transaction record, notification
   */
  static async settleWin(
    gameId: string, winnerId: string, loserId: string,
    reason: string, stakeEach: string,
  ): Promise<SettlementResult> {
    const { prizePool, platformFee, winnerPayout } = SettlementService.calculateWinPayout(stakeEach);

    const { rows: players } = await pool.query(
      `SELECT id, elo FROM users WHERE id = ANY($1::uuid[])`, [[winnerId, loserId]],
    );
    const winnerRow = players.find((p: { id: string; elo: number }) => p.id === winnerId)!;
    const loserRow  = players.find((p: { id: string; elo: number }) => p.id === loserId)!;

    // ELO: winner=player1, loser=player2 in the calculation
    const elo = EloService.calculate(1, winnerRow.elo, loserRow.elo);

    const client = await pool.connect();
    try {
      await client.query('BEGIN');

      // Update game record
      await client.query(
        `UPDATE games SET
           status='completed',
           result=CASE WHEN player1_id=$1 THEN 'player1_win' ELSE 'player2_win' END,
           platform_fee=$2, winner_payout=$3,
           player1_elo_after=CASE WHEN player1_id=$1 THEN $4 ELSE $5 END,
           player2_elo_after=CASE WHEN player1_id=$1 THEN $5 ELSE $4 END,
           ended_at=NOW(), updated_at=NOW()
         WHERE id=$6`,
        [winnerId, platformFee, winnerPayout, elo.player1NewElo, elo.player2NewElo, gameId],
      );

      // Update ELO
      await client.query(`UPDATE users SET elo=$1, updated_at=NOW() WHERE id=$2`, [elo.player1NewElo, winnerId]);
      await client.query(`UPDATE users SET elo=$1, updated_at=NOW() WHERE id=$2`, [elo.player2NewElo, loserId]);

      // Update winner stats
      await client.query(
        `UPDATE users SET games_played=games_played+1, games_won=games_won+1,
           total_won=total_won+$1::numeric, total_wagered=total_wagered+$2::numeric, updated_at=NOW()
         WHERE id=$3`,
        [winnerPayout, stakeEach, winnerId],
      );

      // Update loser stats
      await client.query(
        `UPDATE users SET games_played=games_played+1, games_lost=games_lost+1,
           total_wagered=total_wagered+$1::numeric, updated_at=NOW() WHERE id=$2`,
        [stakeEach, loserId],
      );

      // Settle balances: remove locked stake from both, credit winner
      await client.query(
        `UPDATE balances SET locked=locked-$1::numeric, updated_at=NOW() WHERE user_id=$2`,
        [stakeEach, winnerId],
      );
      await client.query(
        `UPDATE balances SET locked=locked-$1::numeric, updated_at=NOW() WHERE user_id=$2`,
        [stakeEach, loserId],
      );
      await client.query(
        `UPDATE balances SET available=available+$1::numeric, updated_at=NOW() WHERE user_id=$2`,
        [winnerPayout, winnerId],
      );

      // Transaction record for winner's payout credit
      await client.query(
        `INSERT INTO transactions (user_id, type, status, amount) VALUES ($1,'deposit','confirmed',$2)`,
        [winnerId, winnerPayout],
      );

      await client.query('COMMIT');
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }

    // Telegram notifications (PRD §11)
    await NotificationService.send(winnerId, 'game_result', {
      won: true, payout: winnerPayout, fee: platformFee,
      eloChange: `+${elo.player1Delta}`,
    });
    await NotificationService.send(loserId, 'game_result', {
      won: false, eloChange: `${elo.player2Delta}`,
    });

    const result: SettlementResult = {
      gameId, winnerId, loserId, stake: stakeEach, prizePool, platformFee, winnerPayout,
      eloChanges: {
        winner: { before: winnerRow.elo, after: elo.player1NewElo, delta: elo.player1Delta },
        loser:  { before: loserRow.elo,  after: elo.player2NewElo, delta: elo.player2Delta },
      },
    };

    logger.info(
      `Settled: game=${gameId} winner=${winnerId} payout=${winnerPayout} ` +
      `fee=${platformFee} eloW=+${elo.player1Delta} eloL=${elo.player2Delta} reason=${reason}`,
    );
    return result;
  }

  /**
   * Draw settlement — PRD §12: stakes returned, zero fee, zero ELO change
   */
  static async settleDraw(
    gameId: string, player1Id: string, player2Id: string, stakeEach: string,
  ): Promise<DrawResult> {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');

      await client.query(
        `UPDATE games SET status='completed', result='draw',
           player1_elo_after=player1_elo_before, player2_elo_after=player2_elo_before,
           platform_fee=0, winner_payout=0, ended_at=NOW(), updated_at=NOW()
         WHERE id=$1`,
        [gameId],
      );

      // Stats: only games_played + games_drawn, no ELO change
      await client.query(
        `UPDATE users SET games_played=games_played+1, games_drawn=games_drawn+1,
           total_wagered=total_wagered+$1::numeric, updated_at=NOW()
         WHERE id=ANY($2::uuid[])`,
        [stakeEach, [player1Id, player2Id]],
      );

      // Unlock stakes back to available
      await client.query(
        `UPDATE balances SET locked=locked-$1::numeric, available=available+$1::numeric,
           updated_at=NOW() WHERE user_id=ANY($2::uuid[])`,
        [stakeEach, [player1Id, player2Id]],
      );

      await client.query('COMMIT');
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }

    logger.info(`Draw: game=${gameId} stake=${stakeEach} returned to both`);
    return { gameId, player1Id, player2Id, stake: stakeEach };
  }
}
