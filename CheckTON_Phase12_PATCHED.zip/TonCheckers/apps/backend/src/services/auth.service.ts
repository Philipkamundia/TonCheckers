import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import pool from '../config/db.js';
import { generateUniqueUsername } from '../utils/usernameGenerator.js';
import { AppError } from '../middleware/errorHandler.js';
import { logger } from '../utils/logger.js';
import type { ConnectWalletInput } from '../validation/auth.js';

export interface AuthPayload {
  userId:        string;
  walletAddress: string;
}

export interface AuthTokens {
  accessToken:  string;
  refreshToken: string;
  expiresIn:    number;
}

export interface UserProfile {
  id:            string;
  walletAddress: string;
  username:      string;
  elo:           number;
  gamesPlayed:   number;
  gamesWon:      number;
  gamesLost:     number;
  gamesDrawn:    number;
  totalWon:      string;
  createdAt:     string;
}

export class AuthService {

  // ─── Token helpers ────────────────────────────────────────────────────────

  static issueTokens(userId: string, walletAddress: string): AuthTokens {
    const payload: AuthPayload = { userId, walletAddress };
    const expiresIn = 60 * 60 * 24; // 24h in seconds

    const accessToken = jwt.sign(payload, process.env.JWT_SECRET!, { expiresIn });
    const refreshToken = jwt.sign(
      { userId, walletAddress, type: 'refresh' },
      process.env.JWT_REFRESH_SECRET!,
      { expiresIn: '7d' },
    );

    return { accessToken, refreshToken, expiresIn };
  }

  static verifyAccessToken(token: string): AuthPayload {
    try {
      return jwt.verify(token, process.env.JWT_SECRET!) as AuthPayload;
    } catch {
      throw new AppError(401, 'Invalid or expired token', 'TOKEN_INVALID');
    }
  }

  static verifyRefreshToken(token: string): AuthPayload {
    try {
      const payload = jwt.verify(token, process.env.JWT_REFRESH_SECRET!) as AuthPayload & { type: string };
      if (payload.type !== 'refresh') throw new AppError(401, 'Not a refresh token', 'TOKEN_INVALID');
      return { userId: payload.userId, walletAddress: payload.walletAddress };
    } catch (err) {
      if (err instanceof AppError) throw err;
      throw new AppError(401, 'Invalid or expired refresh token', 'TOKEN_INVALID');
    }
  }

  // ─── TonConnect proof verification ───────────────────────────────────────

  /**
   * Verifies TonConnect proof signature per TonConnect v2 spec.
   *
   * Message construction:
   *   "ton-proof-item-v2/" || domain_len_LE_u32 || domain || timestamp_LE_u64 || payload
   * Final signed message:
   *   0xFF 0x00 || "ton-connect" || SHA256(message)
   * Verification:
   *   Ed25519.verify(SHA256(finalMsg), signature, walletPublicKey)
   *
   * The wallet public key is extracted from the stateInit field provided
   * by TonConnect at connection time (24-byte pubkey in standard WalletV4 stateInit).
   */
  static async verifyTonConnectProof(
    walletAddress: string,
    proof: ConnectWalletInput['proof'],
  ): Promise<boolean> {
    // Must not be older than 5 minutes
    const age = Math.floor(Date.now() / 1000) - proof.timestamp;
    if (age > 300) {
      logger.warn(`TonConnect proof expired: ${age}s old for ${walletAddress}`);
      return false;
    }

    if (!proof.stateInit) {
      logger.warn(`TonConnect proof missing stateInit for ${walletAddress}`);
      return false;
    }

    try {
      // 1. Build the signed message per TonConnect v2 spec
      const domainBuf = Buffer.from(proof.domain.value);
      const domainLen = Buffer.allocUnsafe(4);
      domainLen.writeUInt32LE(domainBuf.length);
      const tsBuf = Buffer.allocUnsafe(8);
      tsBuf.writeBigUInt64LE(BigInt(proof.timestamp));

      const message = Buffer.concat([
        Buffer.from('ton-proof-item-v2/'),
        domainLen,
        domainBuf,
        tsBuf,
        Buffer.from(proof.payload),
      ]);
      const msgHash = crypto.createHash('sha256').update(message).digest();

      const finalMsg = Buffer.concat([
        Buffer.from([0xff, 0x00]),
        Buffer.from('ton-connect'),
        msgHash,
      ]);
      const finalHash = crypto.createHash('sha256').update(finalMsg).digest();

      // 2. Extract Ed25519 public key from stateInit
      //    Standard WalletV4R2 stateInit: the 32-byte public key sits at bytes 6..38
      //    of the data cell after base64 decoding.
      const stateInitBuf = Buffer.from(proof.stateInit, 'base64');
      if (stateInitBuf.length < 38) {
        logger.warn(`stateInit too short (${stateInitBuf.length}B) for ${walletAddress}`);
        return false;
      }
      const publicKey = stateInitBuf.slice(6, 38);

      // 3. Verify Ed25519 signature
      const signature = Buffer.from(proof.signature, 'base64');
      if (signature.length !== 64) {
        logger.warn(`Invalid signature length ${signature.length} for ${walletAddress}`);
        return false;
      }

      const isValid = crypto.verify(
        null,               // Ed25519 uses null algorithm identifier
        finalHash,
        { key: publicKey, format: 'raw', type: 'public', dsaEncoding: 'ieee-p1363' } as crypto.KeyLike,
        signature,
      );

      if (!isValid) {
        logger.warn(`TonConnect Ed25519 signature invalid for ${walletAddress}`);
        return false;
      }

      logger.info(`TonConnect proof verified for ${walletAddress}`);
      return true;
    } catch (err) {
      logger.error(`TonConnect proof verification error for ${walletAddress}:`, err);
      return false;
    }
  }

  // ─── User lookup / creation ───────────────────────────────────────────────

  static async findByWallet(walletAddress: string): Promise<UserProfile | null> {
    const { rows } = await pool.query(
      `SELECT id, wallet_address AS "walletAddress", username, elo,
              games_played  AS "gamesPlayed",  games_won  AS "gamesWon",
              games_lost    AS "gamesLost",    games_drawn AS "gamesDrawn",
              total_won::text AS "totalWon",   created_at  AS "createdAt"
       FROM users WHERE wallet_address = $1`,
      [walletAddress],
    );
    return (rows[0] as UserProfile) ?? null;
  }

  static async findById(userId: string): Promise<UserProfile | null> {
    const { rows } = await pool.query(
      `SELECT id, wallet_address AS "walletAddress", username, elo,
              games_played  AS "gamesPlayed",  games_won  AS "gamesWon",
              games_lost    AS "gamesLost",    games_drawn AS "gamesDrawn",
              total_won::text AS "totalWon",   created_at  AS "createdAt"
       FROM users WHERE id = $1`,
      [userId],
    );
    return (rows[0] as UserProfile) ?? null;
  }

  static async createUser(walletAddress: string, telegramId?: string): Promise<UserProfile> {
    const username = await generateUniqueUsername(async (candidate) => {
      const { rows } = await pool.query(
        'SELECT 1 FROM users WHERE username = $1', [candidate],
      );
      return rows.length > 0;
    });

    const client = await pool.connect();
    try {
      await client.query('BEGIN');

      const { rows: [user] } = await client.query(
        `INSERT INTO users (wallet_address, username, elo, telegram_id)
         VALUES ($1, $2, 1200, $3)
         RETURNING id, wallet_address AS "walletAddress", username, elo,
                   games_played AS "gamesPlayed", games_won AS "gamesWon",
                   games_lost AS "gamesLost", games_drawn AS "gamesDrawn",
                   total_won::text AS "totalWon", created_at AS "createdAt"`,
        [walletAddress, username, telegramId ?? null],
      );

      await client.query(
        'INSERT INTO balances (user_id, available, locked) VALUES ($1, 0, 0)',
        [user.id],
      );

      await client.query('COMMIT');
      logger.info(`New user: ${username} wallet=${walletAddress}`);
      return user as UserProfile;
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }
  }

  // ─── Main auth flows ──────────────────────────────────────────────────────

  /**
   * POST /auth/connect
   * Verifies TonConnect Ed25519 proof. No Telegram initData required.
   * Creates or finds the user and returns a JWT pair.
   */
  static async connect(
    walletAddress: string,
    proof: ConnectWalletInput['proof'],
  ): Promise<{ user: UserProfile; tokens: AuthTokens; isNew: boolean }> {
    const proofValid = await AuthService.verifyTonConnectProof(walletAddress, proof);
    if (!proofValid) {
      throw new AppError(401, 'Invalid TonConnect proof', 'PROOF_INVALID');
    }

    let user = await AuthService.findByWallet(walletAddress);
    const isNew = !user;
    if (!user) user = await AuthService.createUser(walletAddress);

    const tokens = AuthService.issueTokens(user.id, walletAddress);
    return { user, tokens, isNew };
  }

  /**
   * POST /auth/reconnect
   * Re-authenticate an existing user on app resume.
   * Requires a fresh TonConnect proof — no weaker fallback.
   */
  static async reconnect(
    walletAddress: string,
    proof: ConnectWalletInput['proof'],
  ): Promise<{ user: UserProfile; tokens: AuthTokens }> {
    const proofValid = await AuthService.verifyTonConnectProof(walletAddress, proof);
    if (!proofValid) {
      throw new AppError(401, 'Invalid TonConnect proof', 'PROOF_INVALID');
    }

    const user = await AuthService.findByWallet(walletAddress);
    if (!user) {
      throw new AppError(404, 'Wallet not registered — use /auth/connect first', 'USER_NOT_FOUND');
    }

    const tokens = AuthService.issueTokens(user.id, walletAddress);
    return { user, tokens };
  }

  /** POST /auth/refresh — new access token from refresh token */
  static async refresh(
    refreshToken: string,
  ): Promise<{ accessToken: string; expiresIn: number }> {
    const payload = AuthService.verifyRefreshToken(refreshToken);

    const user = await AuthService.findById(payload.userId);
    if (!user) throw new AppError(401, 'User no longer exists', 'USER_NOT_FOUND');

    const tokens = AuthService.issueTokens(payload.userId, payload.walletAddress);
    return { accessToken: tokens.accessToken, expiresIn: tokens.expiresIn };
  }
}
