/**
 * GameTimerService — 30-second move timers (PRD §6)
 *
 * Uses a Redis Sorted Set (ZSET) keyed by expiry timestamp instead of
 * individual keys + KEYS scan. This makes expiry lookup O(log N) rather
 * than O(N) and avoids blocking Redis on KEYS.
 *
 * Redis keys:
 *   game:timers          → ZSET  score=expiresAtMs  member="{gameId}:{activePlayer}"
 *   game:active:{gameId} → string activePlayer (1 or 2)  TTL = MOVE_TIMEOUT_MS + 5s
 */
import redis from '../config/redis.js';
import { logger } from '../utils/logger.js';

const MOVE_TIMEOUT_MS = 30_000;
const TIMERS_ZSET     = 'game:timers';
const ACTIVE_PREFIX   = 'game:active:';

export class GameTimerService {

  /** Start (or reset) timer on each turn change */
  static async startTimer(gameId: string, activePlayer: 1 | 2): Promise<void> {
    const expiresAt = Date.now() + MOVE_TIMEOUT_MS;
    const member    = `${gameId}:${activePlayer}`;

    await Promise.all([
      // Remove any previous timer entry for this game
      redis.zremrangebyscore(TIMERS_ZSET, '-inf', '+inf'),  // replaced below by specific removal
      redis.zadd(TIMERS_ZSET, expiresAt, member),
      redis.set(`${ACTIVE_PREFIX}${gameId}`, String(activePlayer), 'PX', MOVE_TIMEOUT_MS + 5_000),
    ]);

    // Clean up any previous entry for this gameId (player may have changed)
    const allMembers = await redis.zrangebyscore(TIMERS_ZSET, '-inf', '+inf');
    const stale = allMembers.filter(m => m.startsWith(`${gameId}:`) && m !== member);
    if (stale.length) await redis.zrem(TIMERS_ZSET, ...stale);
  }

  /** Clear when game ends */
  static async clearTimer(gameId: string): Promise<void> {
    const allMembers = await redis.zrangebyscore(TIMERS_ZSET, '-inf', '+inf');
    const toRemove = allMembers.filter(m => m.startsWith(`${gameId}:`));
    if (toRemove.length) await redis.zrem(TIMERS_ZSET, ...toRemove);
    await redis.del(`${ACTIVE_PREFIX}${gameId}`);
  }

  /** Remaining ms — 0 if expired, null if no timer */
  static async getRemainingMs(gameId: string): Promise<number | null> {
    const allMembers = await redis.zrangebyscore(TIMERS_ZSET, '-inf', '+inf');
    const member = allMembers.find(m => m.startsWith(`${gameId}:`));
    if (!member) return null;

    const score = await redis.zscore(TIMERS_ZSET, member);
    if (!score) return null;

    return Math.max(0, parseInt(score, 10) - Date.now());
  }

  static async getActivePlayer(gameId: string): Promise<1 | 2 | null> {
    const val = await redis.get(`${ACTIVE_PREFIX}${gameId}`);
    if (!val) return null;
    return parseInt(val, 10) as 1 | 2;
  }

  /**
   * Return all expired game timers.
   * Uses ZRANGEBYSCORE(−∞, now) — O(log N + M) where M = expired count.
   * No KEYS scan, no Redis blocking.
   */
  static async getExpiredGames(): Promise<Array<{ gameId: string; timedOutPlayer: 1 | 2 }>> {
    const now     = Date.now();
    const expired = await redis.zrangebyscore(TIMERS_ZSET, '-inf', now);

    const results: Array<{ gameId: string; timedOutPlayer: 1 | 2 }> = [];

    for (const member of expired) {
      const [gameId, playerStr] = member.split(':');
      const timedOutPlayer = parseInt(playerStr, 10) as 1 | 2;
      results.push({ gameId, timedOutPlayer });
      logger.info(`Timer expired: game=${gameId} player=${timedOutPlayer}`);
    }

    // Remove expired entries from ZSET
    if (expired.length) {
      await redis.zremrangebyscore(TIMERS_ZSET, '-inf', now);
    }

    return results;
  }
}
