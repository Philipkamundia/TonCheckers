/**
 * WithdrawalService — Full withdrawal flow (PRD §4)
 *
 * Rules:
 * - Destination locked to connected wallet only
 * - Balance deducted atomically in the same DB transaction that creates the record
 * - Daily limit: 100 TON per UTC day (tracked for ALL withdrawals, including large ones)
 * - Above 100 TON: held in admin review queue
 * - Cooldown: 30 min between withdrawals (Redis TTL key)
 * - TON transfer signed from hot wallet, status updated only after on-chain confirmation
 * - Telegram bot notification on sent
 *
 * Redis keys:
 *   withdrawal:cooldown:{userId}              → TTL 1800s (30 min)
 *   withdrawal:daily:{userId}:{utcDate}        → sum of today's withdrawals
 */

import pool from '../config/db.js';
import redis from '../config/redis.js';
import { NotificationService } from './notification.service.js';
import { toNano, fromNano, addTon, gte } from '../utils/ton-math.js';
import { AppError } from '../middleware/errorHandler.js';
import { logger } from '../utils/logger.js';

const MAX_DAILY_TON     = parseFloat(process.env.MAX_DAILY_WITHDRAWAL_TON || '100');
const COOLDOWN_SECS     = 1800;
const COOLDOWN_PREFIX   = 'withdrawal:cooldown:';
const DAILY_PREFIX      = 'withdrawal:daily:';

// Poll interval and max attempts when waiting for on-chain confirmation
const CONFIRM_POLL_MS       = 4_000;
const CONFIRM_MAX_ATTEMPTS  = 15;

/**
 * Hot wallet keypair — derived once at first use and cached in memory.
 * Avoids expensive mnemonic derivation on every withdrawal.
 */
let _cachedKeyPair: { publicKey: Buffer; secretKey: Buffer } | null = null;

async function getHotWalletKeyPair(): Promise<{ publicKey: Buffer; secretKey: Buffer }> {
  if (_cachedKeyPair) return _cachedKeyPair;
  const mnemonic = process.env.HOT_WALLET_MNEMONIC;
  if (!mnemonic) throw new Error('HOT_WALLET_MNEMONIC not configured');
  const { mnemonicToPrivateKey } = await import('@ton/crypto');
  const words = mnemonic.trim().split(/\s+/);
  _cachedKeyPair = await mnemonicToPrivateKey(words);
  return _cachedKeyPair;
}

export interface WithdrawalRequest {
  userId:            string;
  walletAddress:     string;
  amount:            string;
  requiresReview:    boolean;
  transactionId:     string;
}

export class WithdrawalService {

  /**
   * POST /balance/withdraw
   *
   * All validation + atomic balance deduction inside a single DB transaction.
   * Under 100 TON: deduct and process immediately.
   * 100 TON or above: deduct and queue for admin approval.
   */
  static async requestWithdrawal(
    userId:      string,
    amount:      string,
    destination: string,
  ): Promise<WithdrawalRequest> {
    // Validate and parse amount using integer nanoTON arithmetic
    let amountNano: bigint;
    try {
      amountNano = toNano(amount);
    } catch {
      throw new AppError(400, 'Invalid amount format', 'INVALID_AMOUNT');
    }
    if (amountNano <= 0n) {
      throw new AppError(400, 'Amount must be a positive number', 'INVALID_AMOUNT');
    }
    const amountNum = Number(amountNano) / 1_000_000_000; // only used for legacy comparisons below

    // 1. Verify destination matches connected wallet
    const { rows: [user] } = await pool.query(
      'SELECT wallet_address FROM users WHERE id = $1', [userId],
    );
    if (!user) throw new AppError(404, 'User not found', 'NOT_FOUND');

    if (user.wallet_address.toLowerCase() !== destination.toLowerCase()) {
      throw new AppError(400, 'Withdrawal destination must match your connected wallet', 'INVALID_DESTINATION');
    }

    // 2. Cooldown check
    const cooldownKey = `${COOLDOWN_PREFIX}${userId}`;
    const onCooldown  = await redis.get(cooldownKey);
    if (onCooldown) {
      const ttl = await redis.ttl(cooldownKey);
      throw new AppError(429, `Withdrawal cooldown active. Try again in ${Math.ceil(ttl / 60)} minutes.`, 'COOLDOWN_ACTIVE');
    }

    // 3. Daily limit check — applies to ALL withdrawals regardless of size
    const utcDate  = new Date().toISOString().slice(0, 10);
    const dailyKey = `${DAILY_PREFIX}${userId}:${utcDate}`;
    const dailyStr  = await redis.get(dailyKey);
    const dailyUsed = dailyStr ? dailyStr : '0.000000000';
    const maxDaily  = MAX_DAILY_TON.toFixed(9);

    const requiresReview = gte(amount, maxDaily);

    // Even large withdrawals consume the daily total
    const newDailyTotal = addTon(dailyUsed, amount);
    if (!requiresReview && gte(newDailyTotal, maxDaily)) {
      const remaining = fromNano(toNano(maxDaily) - toNano(dailyUsed));
      throw new AppError(
        400,
        `Daily limit reached. You can withdraw up to ${remaining} TON today.`,
        'DAILY_LIMIT_EXCEEDED',
      );
    }

    // 4. Balance deduction + transaction record in a single atomic DB transaction
    //    This eliminates the TOCTOU gap between checking and deducting.
    const client = await pool.connect();
    let transactionId: string;
    try {
      await client.query('BEGIN');

      // Atomic deduction: only succeeds if available >= amount
      const { rowCount } = await client.query(
        `UPDATE balances
         SET available = available - $1::numeric,
             updated_at = NOW()
         WHERE user_id = $2
           AND available >= $1::numeric`,
        [amount, userId],
      );
      if (!rowCount) {
        await client.query('ROLLBACK');
        throw new AppError(400, 'Insufficient balance', 'INSUFFICIENT_BALANCE');
      }

      const { rows: [tx] } = await client.query(
        `INSERT INTO transactions
           (user_id, type, status, amount, destination, requires_review)
         VALUES ($1, 'withdrawal', $2, $3, $4, $5)
         RETURNING id`,
        [userId, requiresReview ? 'pending' : 'processing', amount, destination, requiresReview],
      );
      transactionId = tx.id;

      await client.query('COMMIT');
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }

    // 5. Update daily total and set cooldown in Redis
    //    Daily total is updated for ALL withdrawals (including large ones)
    const secsUntilMidnight = WithdrawalService.secsUntilUtcMidnight();
    await redis.set(dailyKey, newDailyTotal, 'EX', secsUntilMidnight);
    await redis.set(cooldownKey, '1', 'EX', COOLDOWN_SECS);

    logger.info(`Withdrawal requested: user=${userId} amount=${amount} TON dest=${destination} review=${requiresReview}`);

    // 6. Process immediately if under limit — fire and forget
    if (!requiresReview) {
      WithdrawalService.processWithdrawal(transactionId, userId, destination, amount)
        .catch(err => logger.error(`Withdrawal processing failed: ${err.message}`));
    }

    return { userId, walletAddress: destination, amount, requiresReview, transactionId };
  }

  /**
   * Sign and broadcast TON transfer from hot wallet.
   * Waits for on-chain confirmation before marking as 'sent'.
   * On failure, refunds the deducted balance.
   */
  static async processWithdrawal(
    transactionId: string,
    userId:        string,
    destination:   string,
    amount:        string,
  ): Promise<void> {
    try {
      await pool.query(
        `UPDATE transactions SET status='processing', updated_at=NOW() WHERE id=$1`,
        [transactionId],
      );

      const { txHash, lt } = await WithdrawalService.sendTonTransfer(destination, amount);

      await pool.query(
        `UPDATE transactions SET status='sent', ton_tx_hash=$1, updated_at=NOW() WHERE id=$2`,
        [txHash, transactionId],
      );

      await NotificationService.send(userId, 'withdrawal_processed', { amount, txHash });
      logger.info(`Withdrawal sent: user=${userId} amount=${amount} TON lt=${lt} hash=${txHash}`);
    } catch (err) {
      await pool.query(
        `UPDATE transactions SET status='failed', updated_at=NOW() WHERE id=$1`,
        [transactionId],
      );
      // Refund balance on failure
      await pool.query(
        `UPDATE balances SET available = available + $1::numeric, updated_at = NOW() WHERE user_id = $2`,
        [amount, userId],
      );
      logger.error(`Withdrawal failed and refunded: txId=${transactionId} err=${(err as Error).message}`);
      throw err;
    }
  }

  /**
   * Sign and broadcast a TON transfer from the hot wallet.
   * Waits for on-chain confirmation and returns the real transaction hash + lt.
   */
  static async sendTonTransfer(
    destination: string,
    amount:      string,
  ): Promise<{ txHash: string; lt: string }> {
    const network = process.env.TON_NETWORK || 'testnet';
    const apiKey  = process.env.TON_API_KEY;

    const { TonClient, WalletContractV4, internal } = await import('@ton/ton');
    const { Address, toNano }                        = await import('@ton/core');

    const endpoint = network === 'mainnet'
      ? 'https://toncenter.com/api/v2/jsonRPC'
      : 'https://testnet.toncenter.com/api/v2/jsonRPC';

    const client  = new TonClient({ endpoint, apiKey });
    const keyPair = await getHotWalletKeyPair();

    const wallet   = WalletContractV4.create({ publicKey: keyPair.publicKey, workchain: 0 });
    const contract = client.open(wallet);
    const seqno    = await contract.getSeqno();

    const toAddress  = Address.parse(destination);
    const nanoAmount = toNano(amount);

    await contract.sendTransfer({
      seqno,
      secretKey: keyPair.secretKey,
      messages: [
        internal({
          to:    toAddress,
          value: nanoAmount,
          body:  'CheckTON withdrawal',
        }),
      ],
    });

    // Poll for on-chain confirmation — do NOT mark sent until confirmed
    const walletAddr = wallet.address.toString();
    const base = network === 'mainnet'
      ? 'https://toncenter.com/api/v2'
      : 'https://testnet.toncenter.com/api/v2';

    for (let attempt = 0; attempt < CONFIRM_MAX_ATTEMPTS; attempt++) {
      await new Promise(r => setTimeout(r, CONFIRM_POLL_MS));

      const url = `${base}/getTransactions?address=${walletAddr}&limit=10${apiKey ? `&api_key=${apiKey}` : ''}`;
      const res  = await fetch(url);
      if (!res.ok) continue;

      const data = await res.json() as { ok: boolean; result: unknown[] };
      if (!data.ok) continue;

      for (const item of data.result) {
        const tx  = item as Record<string, unknown>;
        const tid = tx.transaction_id as Record<string, unknown> | undefined;
        // Match by seqno via out_msgs or by checking the out message value
        const outMsgs = tx.out_msgs as unknown[] | undefined;
        if (!outMsgs?.length) continue;

        const outMsg = outMsgs[0] as Record<string, unknown>;
        const msgDest = String(outMsg.destination || '');
        const msgVal  = String(outMsg.value || '0');

        // Confirm this is our transaction: destination matches and amount is within 0.01 TON
        // (small tolerance for fees subtracted from nanoAmount)
        if (
          msgDest.toLowerCase() === destination.toLowerCase() &&
          Math.abs(Number(msgVal) - Number(nanoAmount)) < 10_000_000  // 0.01 TON tolerance
        ) {
          const txHash = String(tid?.hash || '');
          const lt     = String(tid?.lt || tx.lt || '');
          logger.info(`TON transfer confirmed: ${amount} TON → ${destination} lt=${lt} hash=${txHash}`);
          return { txHash, lt };
        }
      }
    }

    throw new Error(
      `TON transfer confirmation timeout after ${CONFIRM_MAX_ATTEMPTS * CONFIRM_POLL_MS / 1000}s — ` +
      `seqno=${seqno} dest=${destination} amount=${amount}`,
    );
  }

  /**
   * Admin approval: process a held withdrawal (>= 100 TON).
   */
  static async approveWithdrawal(transactionId: string, adminNote?: string): Promise<void> {
    const { rows: [tx] } = await pool.query(
      `SELECT id, user_id, amount::text, destination FROM transactions
       WHERE id=$1 AND requires_review=true AND status='pending'`,
      [transactionId],
    );
    if (!tx) throw new AppError(404, 'Pending withdrawal not found', 'NOT_FOUND');

    if (adminNote) {
      await pool.query(
        `UPDATE transactions SET admin_note=$1, updated_at=NOW() WHERE id=$2`,
        [adminNote, transactionId],
      );
    }

    await WithdrawalService.processWithdrawal(transactionId, tx.user_id, tx.destination, tx.amount);
    logger.info(`Admin approved withdrawal: txId=${transactionId} amount=${tx.amount} TON`);
  }

  /**
   * Admin rejection: cancel a held withdrawal and return funds.
   */
  static async rejectWithdrawal(transactionId: string, reason: string): Promise<void> {
    const { rows: [tx] } = await pool.query(
      `SELECT id, user_id, amount::text FROM transactions
       WHERE id=$1 AND requires_review=true AND status='pending'`,
      [transactionId],
    );
    if (!tx) throw new AppError(404, 'Pending withdrawal not found', 'NOT_FOUND');

    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      await client.query(
        `UPDATE transactions SET status='rejected', admin_note=$1, updated_at=NOW() WHERE id=$2`,
        [reason, transactionId],
      );
      await client.query(
        `UPDATE balances SET available = available + $1::numeric, updated_at = NOW() WHERE user_id = $2`,
        [tx.amount, tx.user_id],
      );
      await client.query('COMMIT');
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }

    logger.info(`Admin rejected withdrawal: txId=${transactionId} reason=${reason}`);
  }

  /** Get all pending withdrawals awaiting admin review */
  static async getPendingReviewWithdrawals(): Promise<unknown[]> {
    const { rows } = await pool.query(
      `SELECT t.id, t.user_id, u.username, t.amount::text, t.destination, t.created_at
       FROM transactions t
       JOIN users u ON u.id = t.user_id
       WHERE t.requires_review=true AND t.status='pending'
       ORDER BY t.created_at ASC`,
    );
    return rows;
  }

  private static secsUntilUtcMidnight(): number {
    const now      = new Date();
    const midnight = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + 1));
    return Math.ceil((midnight.getTime() - now.getTime()) / 1000);
  }
}
