/**
 * Centralized Error Messages for TonCheckers Backend
 * 
 * This file contains all error messages used across services to ensure consistency
 * and make validation tests more maintainable.
 */

export const TREASURY_ERRORS = {
  // Balance and withdrawal errors
  INSUFFICIENT_BALANCE: 'Insufficient balance',
  INSUFFICIENT_AVAILABLE_BALANCE: 'Insufficient available balance for withdrawal (including security buffer)',
  WITHDRAWAL_AMOUNT_EXCEEDS_LIMIT: 'Withdrawal amount exceeds maximum limit',
  DAILY_WITHDRAWAL_LIMIT_EXCEEDED: 'Daily withdrawal limit exceeded',
  
  // User validation errors
  USER_NOT_FOUND: 'User account not found',
  USER_ID_REQUIRED: 'User ID and reference ID are required',
  
  // HSM and security errors
  HSM_SIGNING_REQUIRED: 'HSM signing is required for high-security withdrawals',
  HSM_SIGNATURE_VERIFICATION_FAILED: 'HSM signature verification failed',
  WITHDRAWAL_SIGNING_FAILED: 'Withdrawal signing failed',
  
  // Account validation errors
  ACCOUNT_TOO_NEW: 'Account must be at least 7 days old for large withdrawals',
  
  // Escrow and processing errors
  WITHDRAWAL_ESCROW_NOT_FOUND: 'Withdrawal escrow not found or already processed',
  WITHDRAWAL_VALIDATION_FAILED: 'Withdrawal validation failed',
  
  // Business rule violations
  BUSINESS_RULE_VIOLATION: 'BUSINESS_RULE_VIOLATION'
} as const;

export const GAME_ERRORS = {
  GAME_NOT_FOUND: 'Game not found',
  INVALID_MOVE: 'Invalid move',
  GAME_ALREADY_FINISHED: 'Game already finished'
} as const;

export const USER_ERRORS = {
  USER_NOT_FOUND: 'User not found',
  INVALID_CREDENTIALS: 'Invalid credentials',
  USER_ALREADY_EXISTS: 'User already exists'
} as const;

export const VALIDATION_ERRORS = {
  VALIDATION_ERROR: 'ValidationError',
  INVALID_INPUT: 'Invalid input provided',
  REQUIRED_FIELD_MISSING: 'Required field is missing'
} as const;

// Export all error constants for easy importing
export const ERROR_MESSAGES = {
  ...TREASURY_ERRORS,
  ...GAME_ERRORS,
  ...USER_ERRORS,
  ...VALIDATION_ERRORS
} as const;

// Type for error message keys
export type ErrorMessageKey = keyof typeof ERROR_MESSAGES;