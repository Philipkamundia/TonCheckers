/**
 * elo.test.ts — Unit tests for EloService
 *
 * Verifies all PRD §7 rules:
 * - K-factor tiers (40/24/16/10)
 * - Expected score formula
 * - Win/loss/draw ELO deltas
 * - Draw = zero ELO change
 */

import { describe, it, expect } from 'vitest';
import { EloService } from '../services/elo.service.js';

describe('K-factor tiers (PRD §7)', () => {
  it('returns 40 for ELO < 1400 (Beginner)', () => {
    expect(EloService.getKFactor(800)).toBe(40);
    expect(EloService.getKFactor(1200)).toBe(40);
    expect(EloService.getKFactor(1399)).toBe(40);
  });

  it('returns 24 for ELO 1400–1799 (Intermediate)', () => {
    expect(EloService.getKFactor(1400)).toBe(24);
    expect(EloService.getKFactor(1600)).toBe(24);
    expect(EloService.getKFactor(1799)).toBe(24);
  });

  it('returns 16 for ELO 1800–2199 (Advanced)', () => {
    expect(EloService.getKFactor(1800)).toBe(16);
    expect(EloService.getKFactor(2000)).toBe(16);
    expect(EloService.getKFactor(2199)).toBe(16);
  });

  it('returns 10 for ELO > 2200 (Elite)', () => {
    expect(EloService.getKFactor(2200)).toBe(10);
    expect(EloService.getKFactor(2800)).toBe(10);
  });
});

describe('Expected score', () => {
  it('returns 0.5 for equal ELO', () => {
    expect(EloService.expectedScore(1200, 1200)).toBeCloseTo(0.5);
  });

  it('higher ELO player has expected score > 0.5', () => {
    expect(EloService.expectedScore(1600, 1200)).toBeGreaterThan(0.5);
  });

  it('lower ELO player has expected score < 0.5', () => {
    expect(EloService.expectedScore(1200, 1600)).toBeLessThan(0.5);
  });
});

describe('ELO calculation — win/loss', () => {
  it('equal ELO 1200 vs 1200: winner gains ~20, loser loses ~20', () => {
    const result = EloService.calculate(1200, 1200, 1);
    // K=40, expected=0.5, delta = 40*(1-0.5) = 20
    expect(result.player1Delta).toBe(20);
    expect(result.player2Delta).toBe(-20);
    expect(result.player1NewElo).toBe(1220);
    expect(result.player2NewElo).toBe(1180);
  });

  it('upset: 1000 ELO beats 1400 ELO — larger gain for underdog', () => {
    const result = EloService.calculate(1000, 1400, 1);
    // Player1 is big underdog — wins, gets large positive delta
    expect(result.player1Delta).toBeGreaterThan(30);
    // Player2 is favourite — loses, gets large negative delta
    expect(result.player2Delta).toBeLessThan(-10);
  });

  it('favourite beats underdog — small gain', () => {
    const result = EloService.calculate(1600, 1200, 1);
    // Player1 (1600) wins — expected high, so delta is small
    expect(result.player1Delta).toBeLessThan(10);
    expect(result.player2Delta).toBeGreaterThan(-20);
  });

  it('player2 wins scenario', () => {
    const result = EloService.calculate(1200, 1200, 2);
    expect(result.player1Delta).toBe(-20);
    expect(result.player2Delta).toBe(20);
    expect(result.player2NewElo).toBe(1220);
  });

  it('ELO floor at 100', () => {
    const result = EloService.calculate(110, 2800, 2);
    // Player1 loses — would go below 100
    expect(result.player1NewElo).toBe(100);
  });
});

describe('Draw — PRD §7: no ELO change', () => {
  it('returns zero deltas for both players on draw', () => {
    const result = EloService.calculate(1200, 1800, 'draw');
    expect(result.player1Delta).toBe(0);
    expect(result.player2Delta).toBe(0);
  });

  it('ELO unchanged on draw', () => {
    const result = EloService.calculate(1500, 1600, 'draw');
    expect(result.player1NewElo).toBe(1500);
    expect(result.player2NewElo).toBe(1600);
  });
});

describe('Payout calculation — PRD §12', () => {
  it('1 TON stake: winner gets 1.70, fee is 0.30', () => {
    const { winnerPayout, platformFee } = require('../services/settlement.service.js')
      .SettlementService.calcWinPayout('1.000000000');
    expect(parseFloat(winnerPayout)).toBeCloseTo(1.70, 9);
    expect(parseFloat(platformFee)).toBeCloseTo(0.30, 9);
  });

  it('5 TON stake: winner gets 8.50, fee is 1.50', () => {
    const { winnerPayout, platformFee } = require('../services/settlement.service.js')
      .SettlementService.calcWinPayout('5.000000000');
    expect(parseFloat(winnerPayout)).toBeCloseTo(8.50, 9);
    expect(parseFloat(platformFee)).toBeCloseTo(1.50, 9);
  });
});
