/**
 * hash.ts — Deterministic board state hashing for draw detection
 *
 * PRD §5: Draw declared when both players have < 5 pieces AND
 * the same board position has been repeated 25 times.
 *
 * Hash includes: board layout + active player
 * Two states with same board but different active player = different hash.
 */

import crypto from 'crypto';
import { Board, Player } from './board.js';

/**
 * Compute a deterministic SHA-256 hash of the board state.
 * Includes active player so position + turn = unique state.
 */
export function hashBoardState(board: Board, activePlayer: Player): string {
  // Flatten board to a compact string: each row joined, rows separated by '|'
  const flat = board.map(row => row.join('')).join('|');
  const input = `${flat}:${activePlayer}`;
  return crypto.createHash('sha256').update(input).digest('hex').slice(0, 16);
}

/**
 * Count how many times a specific hash appears in the history.
 */
export function countRepetitions(history: string[], hash: string): number {
  return history.filter(h => h === hash).length;
}

/**
 * PRD §5: Draw condition check.
 * Returns true if:
 * 1. Both players have fewer than 5 pieces
 * 2. Current board position has been repeated 25 times
 */
export function isDrawByRepetition(
  history:   string[],
  hash:      string,
  p1Pieces:  number,
  p2Pieces:  number,
): boolean {
  if (p1Pieces >= 5 || p2Pieces >= 5) return false;
  return countRepetitions(history, hash) >= 25;
}
