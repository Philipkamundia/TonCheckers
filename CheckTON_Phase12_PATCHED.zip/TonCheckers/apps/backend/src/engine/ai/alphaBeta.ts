/**
 * alphaBeta.ts — Master AI
 * Alpha-beta pruning to depth 8 with enhanced positional evaluation.
 * PRD §8: Master difficulty level — plays competitively
 */

import { Board, Player, Move, Square, P1, P2, P1_KING, P2_KING } from '../board.js';
import { getAvailableMoves } from '../moves.js';
import { applyMoveWithPromotion } from '../rules.js';
import { checkWinCondition } from '../conditions.js';
import { hashBoardState } from '../hash.js';

const AB_DEPTH = 8;

/**
 * Enhanced evaluation function for Master AI.
 * Factors: material, king bonus, advancement bonus, center control, back row protection.
 */
function evaluateEnhanced(board: Board, player: Player): number {
  let score = 0;

  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const sq = board[r][c] as Square;
      if (sq === 0) continue;

      const isPlayer1Piece = sq === P1 || sq === P1_KING;
      const isPlayer2Piece = sq === P2 || sq === P2_KING;
      const isKing         = sq === P1_KING || sq === P2_KING;
      const sign           = (isPlayer1Piece && player === 1) || (isPlayer2Piece && player === 2) ? 1 : -1;

      // Base material value
      let pieceScore = isKing ? 3.0 : 1.0;

      // Advancement bonus — regular pieces rewarded for moving toward promotion
      if (!isKing) {
        const advancementRow = isPlayer1Piece ? (7 - r) : r; // P1 advances toward row 0
        pieceScore += advancementRow * 0.05;
      }

      // Center control bonus (columns 2-5, rows 2-5)
      if (r >= 2 && r <= 5 && c >= 2 && c <= 5) {
        pieceScore += 0.1;
      }

      // Back row protection — keep a piece in back row to deny opponent promotion
      if ((isPlayer1Piece && r === 7) || (isPlayer2Piece && r === 0)) {
        pieceScore += 0.15;
      }

      // King mobility bonus — count available directions
      if (isKing) {
        const directions = [[-1,-1],[-1,1],[1,-1],[1,1]];
        let mobility = 0;
        for (const [dr, dc] of directions) {
          const nr = r + dr, nc = c + dc;
          if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8 && board[nr][nc] === 0) mobility++;
        }
        pieceScore += mobility * 0.05;
      }

      score += sign * pieceScore;
    }
  }

  return score;
}

function alphaBeta(
  board:    Board,
  player:   Player,
  aiPlayer: Player,
  depth:    number,
  alpha:    number,
  beta:     number,
  history:  string[],
): number {
  const result = checkWinCondition(board, player, history);
  if (result.status === 'win')  return result.winner === aiPlayer ? 10000 : -10000;
  if (result.status === 'draw') return 0;
  if (depth === 0)              return evaluateEnhanced(board, aiPlayer);

  const moves    = getAvailableMoves(board, player);
  const isMaxing = player === aiPlayer;

  if (!moves.length) return isMaxing ? -10000 : 10000;

  // Move ordering: evaluate captures first (better pruning)
  const ordered = [...moves].sort((a, b) => b.captures.length - a.captures.length);

  if (isMaxing) {
    let best = -Infinity;
    for (const move of ordered) {
      const newBoard   = applyMoveWithPromotion(board, move);
      const nextPlayer: Player = player === 1 ? 2 : 1;
      const newHash    = hashBoardState(newBoard, nextPlayer);
      const score      = alphaBeta(newBoard, nextPlayer, aiPlayer, depth - 1, alpha, beta, [...history, newHash]);
      best  = Math.max(best, score);
      alpha = Math.max(alpha, best);
      if (beta <= alpha) break; // β cutoff
    }
    return best;
  } else {
    let best = Infinity;
    for (const move of ordered) {
      const newBoard   = applyMoveWithPromotion(board, move);
      const nextPlayer: Player = player === 1 ? 2 : 1;
      const newHash    = hashBoardState(newBoard, nextPlayer);
      const score      = alphaBeta(newBoard, nextPlayer, aiPlayer, depth - 1, alpha, beta, [...history, newHash]);
      best = Math.min(best, score);
      beta = Math.min(beta, best);
      if (beta <= alpha) break; // α cutoff
    }
    return best;
  }
}

export function alphaBetaMove(board: Board, aiPlayer: Player): Move | null {
  const moves = getAvailableMoves(board, aiPlayer);
  if (!moves.length) return null;

  let bestMove  = moves[0];
  let bestScore = -Infinity;
  const alpha   = -Infinity;
  const beta    = Infinity;

  // Move ordering at root: captures first
  const ordered = [...moves].sort((a, b) => b.captures.length - a.captures.length);

  for (const move of ordered) {
    const newBoard   = applyMoveWithPromotion(board, move);
    const nextPlayer: Player = aiPlayer === 1 ? 2 : 1;
    const newHash    = hashBoardState(newBoard, nextPlayer);
    const score      = alphaBeta(newBoard, nextPlayer, aiPlayer, AB_DEPTH - 1, alpha, beta, [newHash]);
    if (score > bestScore) {
      bestScore = score;
      bestMove  = move;
    }
  }

  return bestMove;
}
