/**
 * moves.ts — Legal move generation
 *
 * PRD §5 rules enforced here:
 * - Forced captures: if any jump is available, ONLY jumps are legal
 * - Multi-jump chains: must be completed in one turn
 * - Backward capture: allowed for ALL pieces (regular and kings)
 * - King promotion: blocked mid-chain (applied only after full move)
 */

import {
  Board, Move, Player, Position, Square,
  EMPTY, P1, P2, P1_KING, P2_KING,
  cloneBoard, inBounds, isOwnPiece, isOpponentPiece, isKing,
} from './board.js';

/** Movement directions for each piece type */
function getDirections(square: Square, _player: Player): Array<[number, number]> {
  if (isKing(square)) {
    // Kings move in all 4 diagonal directions
    return [[-1, -1], [-1, 1], [1, -1], [1, 1]];
  }
  if (square === P1) {
    // P1 moves UP (decreasing row) — but can capture backward too (PRD §5)
    return [[-1, -1], [-1, 1]];
  }
  // P2 moves DOWN (increasing row) — but can capture backward too (PRD §5)
  return [[1, -1], [1, 1]];
}

/** All 4 diagonal directions — used for capture detection (backward capture allowed) */
const ALL_DIRECTIONS: Array<[number, number]> = [[-1, -1], [-1, 1], [1, -1], [1, 1]];

/**
 * Get all simple (non-capture) moves for a piece at (row, col).
 * Returns empty array if the piece can jump — caller enforces forced captures.
 */
function getSimpleMoves(board: Board, row: number, col: number, player: Player): Move[] {
  const square  = board[row][col];
  const dirs    = getDirections(square, player);
  const moves: Move[] = [];

  for (const [dr, dc] of dirs) {
    const nr = row + dr;
    const nc = col + dc;
    if (inBounds(nr, nc) && board[nr][nc] === EMPTY) {
      moves.push({
        from:     { row, col },
        to:       { row: nr, col: nc },
        captures: [],
        isChain:  false,
      });
    }
  }

  return moves;
}

/**
 * Recursively find all capture chains from a given position.
 * PRD §5: backward capture allowed for all pieces.
 * PRD §5: king promotion blocked mid-chain.
 *
 * Returns array of complete Move objects (each may have multiple captures).
 */
function getCaptureChains(
  board: Board,
  row: number,
  col: number,
  player: Player,
  captured: Set<string>,  // positions already captured in this chain
  chainPath: Position[],  // positions visited in this chain
  isKingPiece: boolean,
): Move[] {
  const results: Move[] = [];
  // All 4 directions for backward capture (PRD §5)
  const dirs = isKingPiece
    ? ALL_DIRECTIONS
    : ALL_DIRECTIONS; // Regular pieces can also capture backward per PRD §5

  let foundContinuation = false;

  for (const [dr, dc] of dirs) {
    const midRow = row + dr;
    const midCol = col + dc;
    const landRow = row + 2 * dr;
    const landCol = col + 2 * dc;

    if (!inBounds(landRow, landCol)) continue;
    if (board[landRow][landCol] !== EMPTY) continue;

    const midKey = `${midRow},${midCol}`;
    if (captured.has(midKey)) continue; // Can't capture same piece twice

    const midSquare = board[midRow][midCol];
    if (!isOpponentPiece(midSquare, player)) continue;

    // Valid capture — recurse to find continuations
    foundContinuation = true;
    const newCaptured = new Set(captured);
    newCaptured.add(midKey);

    // Apply capture temporarily on a cloned board for recursion
    const tempBoard = cloneBoard(board);
    tempBoard[midRow][midCol] = EMPTY;
    tempBoard[landRow][landCol] = tempBoard[row][col];
    tempBoard[row][col] = EMPTY;
    // NOTE: do NOT promote mid-chain (PRD §5)

    const newPath = [...chainPath, { row: landRow, col: landCol }];
    const continuations = getCaptureChains(
      tempBoard, landRow, landCol, player, newCaptured, newPath, isKingPiece,
    );

    if (continuations.length > 0) {
      results.push(...continuations);
    } else {
      // No further jumps — this is a complete chain
      const allCaptures = Array.from(newCaptured).map(k => {
        const [r, c] = k.split(',').map(Number);
        return { row: r, col: c };
      });
      results.push({
        from:     chainPath[0],
        to:       { row: landRow, col: landCol },
        captures: allCaptures,
        isChain:  chainPath.length > 1,
      });
    }
  }

  return results;
}

/**
 * Get all jump (capture) moves available for a piece.
 */
function getCaptureMoves(board: Board, row: number, col: number, player: Player): Move[] {
  const square    = board[row][col];
  const kingPiece = isKing(square);

  return getCaptureChains(board, row, col, player, new Set(), [{ row, col }], kingPiece);
}

/**
 * Get all legal moves for a specific piece.
 * Respects forced capture rule — returns only jumps if any are available.
 */
export function getLegalMovesForPiece(board: Board, row: number, col: number, player: Player): Move[] {
  const square = board[row][col];
  if (!isOwnPiece(square, player)) return [];

  const captures = getCaptureMoves(board, row, col, player);
  // If captures exist for this piece, only those are returned
  // (full forced-capture enforcement happens in getAvailableMoves)
  return captures.length > 0 ? captures : getSimpleMoves(board, row, col, player);
}

/**
 * Get ALL legal moves for a player.
 * PRD §5 — Forced captures: if ANY jump exists anywhere, ONLY jumps are returned.
 */
export function getAvailableMoves(board: Board, player: Player): Move[] {
  const allCaptures: Move[] = [];
  const allSimple:   Move[] = [];

  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      if (!isOwnPiece(board[row][col], player)) continue;

      const captures = getCaptureMoves(board, row, col, player);
      if (captures.length > 0) {
        allCaptures.push(...captures);
      } else {
        allSimple.push(...getSimpleMoves(board, row, col, player));
      }
    }
  }

  // PRD §5: Forced captures — if any jump exists, only jumps are legal
  return allCaptures.length > 0 ? allCaptures : allSimple;
}

/**
 * Check if the player has any forced capture available.
 */
export function isForcedCapture(board: Board, player: Player): boolean {
  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      if (!isOwnPiece(board[row][col], player)) continue;
      if (getCaptureMoves(board, row, col, player).length > 0) return true;
    }
  }
  return false;
}

/**
 * Validate that a given move is in the list of legal moves.
 */
export function isLegalMove(board: Board, move: Move, player: Player): boolean {
  const legal = getAvailableMoves(board, player);
  return legal.some(m =>
    m.from.row  === move.from.row  &&
    m.from.col  === move.from.col  &&
    m.to.row    === move.to.row    &&
    m.to.col    === move.to.col    &&
    m.captures.length === move.captures.length,
  );
}
