import { AppError } from '../middleware/errorHandler.js';

export const Errors = {
  notFound:      (entity: string) => new AppError(404, `${entity} not found`, 'NOT_FOUND'),
  unauthorized:  ()               => new AppError(401, 'Unauthorized', 'UNAUTHORIZED'),
  forbidden:     ()               => new AppError(403, 'Forbidden', 'FORBIDDEN'),
  badRequest:    (msg: string)    => new AppError(400, msg, 'BAD_REQUEST'),
  conflict:      (msg: string)    => new AppError(409, msg, 'CONFLICT'),
  insufficientBalance: ()         => new AppError(400, 'Insufficient balance', 'INSUFFICIENT_BALANCE'),
  gameNotActive: ()               => new AppError(400, 'Game is not active', 'GAME_NOT_ACTIVE'),
  invalidMove:   (msg: string)    => new AppError(400, msg, 'INVALID_MOVE'),
};

export { AppError };
