/**
 * ton-math.ts — Safe arithmetic for TON amounts
 *
 * TON amounts are stored in the DB as NUMERIC (9 decimal places).
 * All arithmetic is performed in nanoTON (integer BigInt) to avoid
 * floating-point drift. Amounts cross the boundary only at:
 *   - Ingestion from external sources (TON API, user input)
 *   - Display / serialisation to string
 *
 * 1 TON = 1_000_000_000 nanoTON
 */

const NANO = 1_000_000_000n;
const NANO_NUM = 1_000_000_000;
const SCALE = 9; // decimal places stored in DB

/** Convert a TON decimal string (e.g. "1.5") to nanoTON BigInt */
export function toNano(ton: string): bigint {
  const [whole, frac = ''] = ton.trim().split('.');
  const fracPadded = frac.slice(0, SCALE).padEnd(SCALE, '0');
  return BigInt(whole) * NANO + BigInt(fracPadded);
}

/** Convert nanoTON BigInt back to a 9-decimal TON string */
export function fromNano(nano: bigint): string {
  const abs   = nano < 0n ? -nano : nano;
  const sign  = nano < 0n ? '-' : '';
  const whole = abs / NANO;
  const frac  = (abs % NANO).toString().padStart(SCALE, '0');
  return `${sign}${whole}.${frac}`;
}

/** Add two TON decimal strings, return TON decimal string */
export function addTon(a: string, b: string): string {
  return fromNano(toNano(a) + toNano(b));
}

/** Subtract b from a. Throws if result would be negative. */
export function subtractTon(a: string, b: string): string {
  const result = toNano(a) - toNano(b);
  if (result < 0n) throw new Error(`Underflow: ${a} - ${b}`);
  return fromNano(result);
}

/** Multiply a TON string by a fractional rate (e.g. 0.15 for 15% fee).
 *  Uses integer arithmetic: rate expressed as basis points / 10000. */
export function multiplyRate(amount: string, rate: number): string {
  // rate e.g. 0.15 → 1500 basis points
  const bps    = Math.round(rate * 10_000);
  const result = (toNano(amount) * BigInt(bps)) / 10_000n;
  return fromNano(result);
}

/** Compare: returns negative, zero, or positive */
export function compareTon(a: string, b: string): number {
  const diff = toNano(a) - toNano(b);
  return diff < 0n ? -1 : diff > 0n ? 1 : 0;
}

/** Returns true if a >= b */
export function gte(a: string, b: string): boolean {
  return compareTon(a, b) >= 0;
}

/** Parse nanoTON integer string from TON API to TON decimal string */
export function nanoStringToTon(nano: string): string {
  return fromNano(BigInt(nano));
}
