export interface Position {
  x: number;
  y: number;
}

export interface Move {
  from: Position;
  to: Position;
  captures?: Position[];
}

export interface Piece {
  type: 'man' | 'king';
  color: 'black' | 'white';
  position: Position;
}

export interface Board {
  size: number;
  pieces: Piece[];
}

export interface GameVariantRules {
  boardSize: number;
  piecesPerPlayer: number;
  flyingKings: boolean;
  mandatoryCapture: boolean;
  backwardCaptures: boolean;
  manBackwardMoves: boolean;
  chainCaptures: boolean;
  maxCaptureSequence: boolean;
}

export const GAME_VARIANTS: Record<string, GameVariantRules> = {
  american: {
    boardSize: 8,
    piecesPerPlayer: 12,
    flyingKings: false,
    mandatoryCapture: true,
    backwardCaptures: false, // Men can ONLY capture forward
    manBackwardMoves: false,
    chainCaptures: true,
    maxCaptureSequence: false
  },
  international: {
    boardSize: 10,
    piecesPerPlayer: 20,
    flyingKings: true,
    mandatoryCapture: true,
    backwardCaptures: true,
    manBackwardMoves: false,
    chainCaptures: true,
    maxCaptureSequence: true // Must capture maximum pieces
  },
  russian: {
    boardSize: 8,
    piecesPerPlayer: 12,
    flyingKings: true,
    mandatoryCapture: true, // Must capture if possible
    backwardCaptures: true, // Men can capture backwards
    manBackwardMoves: false,
    chainCaptures: true,
    maxCaptureSequence: true // Must capture MAXIMUM pieces (not specific direction)
  },
  turkish: {
    boardSize: 8,
    piecesPerPlayer: 16,
    flyingKings: true, // Kings can fly any distance
    mandatoryCapture: true,
    backwardCaptures: true, // Men can capture backwards
    manBackwardMoves: false, // Men can ONLY move forward (not backward)
    chainCaptures: true,
    maxCaptureSequence: true // Must capture maximum pieces
  }
};

export class GameRules {
  private static isValidPosition(pos: Position, boardSize: number): boolean {
    return pos.x >= 0 && pos.x < boardSize && pos.y >= 0 && pos.y < boardSize;
  }

  private static isMoveInDirection(
    from: Position,
    to: Position,
    rules: GameVariantRules,
    piece: Piece
  ): boolean {
    const dy = to.y - from.y;
    const isForwardMove = (piece.color === 'black' && dy > 0) || (piece.color === 'white' && dy < 0);

    if (piece.type === 'king') {
      return rules.flyingKings || Math.abs(to.x - from.x) === Math.abs(dy);
    }

    if (!isForwardMove && !rules.manBackwardMoves) {
      return false;
    }

    return Math.abs(to.x - from.x) === Math.abs(dy);
  }

  /**
   * Check if ANY piece of a given color can capture
   * This enforces mandatory capture across ALL pieces, not just the selected one
   */
  static hasAnyCapture(board: Board, variant: string, color: 'black' | 'white'): boolean {
    const rules = GAME_VARIANTS[variant];
    if (!rules || !rules.mandatoryCapture) return false;

    const playerPieces = board.pieces.filter(p => p.color === color);
    
    for (const piece of playerPieces) {
      const captures = this.findCaptures(piece, board, rules);
      if (captures.length > 0) {
        return true;
      }
    }
    return false;
  }

  /**
   * Get ALL valid moves for a player, enforcing mandatory capture globally
   */
  static getAllValidMovesForPlayer(
    board: Board,
    variant: string,
    color: 'black' | 'white'
  ): Move[] {
    const rules = GAME_VARIANTS[variant];
    if (!rules) throw new Error('Invalid game variant');

    const playerPieces = board.pieces.filter(p => p.color === color);
    const allMoves: Move[] = [];

    // First check if any capture is available globally
    const hasCapture = this.hasAnyCapture(board, variant, color);

    for (const piece of playerPieces) {
      const pieceMoves = this.getValidMoves(piece, board, variant);
      
      if (hasCapture) {
        // If any capture is available, only allow capture moves
        if (pieceMoves.length > 0 && pieceMoves[0].captures && pieceMoves[0].captures.length > 0) {
          // Filter to only capture moves
          const captureMoves = pieceMoves.filter(m => m.captures && m.captures.length > 0);
          allMoves.push(...captureMoves);
        }
      } else {
        // No captures available, allow regular moves
        allMoves.push(...pieceMoves.filter(m => !m.captures || m.captures.length === 0));
      }
    }

    // If maxCaptureSequence is enabled, filter to only maximum captures
    if (hasCapture && rules.maxCaptureSequence) {
      const maxCaptures = Math.max(...allMoves.map(m => m.captures?.length || 0));
      return allMoves.filter(m => (m.captures?.length || 0) === maxCaptures);
    }

    return allMoves;
  }

  private static getPieceBetween(
    from: Position,
    to: Position,
    board: Board
  ): Piece | null {
    const dx = Math.sign(to.x - from.x);
    const dy = Math.sign(to.y - from.y);
    const midX = from.x + dx;
    const midY = from.y + dy;

    return board.pieces.find(p => p.position.x === midX && p.position.y === midY) || null;
  }

  private static findCaptures(
    piece: Piece,
    board: Board,
    rules: GameVariantRules,
    visited: Set<string> = new Set()
  ): Move[] {
    const captures: Move[] = [];
    const directions = rules.manBackwardMoves || piece.type === 'king' ? [1, -1] : piece.color === 'black' ? [1] : [-1];

    for (const dy of directions) {
      for (const dx of [-1, 1]) {
        const jumpX = piece.position.x + dx * 2;
        const jumpY = piece.position.y + dy * 2;
        const jumpPos = { x: jumpX, y: jumpY };

        if (!this.isValidPosition(jumpPos, board.size)) continue;

        const capturedPiece = this.getPieceBetween(piece.position, jumpPos, board);
        if (!capturedPiece || capturedPiece.color === piece.color) continue;

        const isOccupied = board.pieces.some(p => 
          p.position.x === jumpPos.x && p.position.y === jumpPos.y
        );
        if (isOccupied) continue;

        const positionKey = `${jumpPos.x},${jumpPos.y}`;
        if (visited.has(positionKey)) continue;

        const capture: Move = {
          from: { ...piece.position },
          to: jumpPos,
          captures: [capturedPiece.position]
        };

        captures.push(capture);

        if (rules.chainCaptures) {
          // Create new board state after this capture
          const newBoard: Board = {
            size: board.size,
            pieces: board.pieces
              .filter(p => 
                p.position.x !== capturedPiece.position.x || 
                p.position.y !== capturedPiece.position.y
              )
              .map(p => 
                p === piece 
                  ? { ...p, position: jumpPos }
                  : { ...p }
              )
          };

          visited.add(positionKey);
          const nextCaptures = this.findCaptures(
            { ...piece, position: jumpPos },
            newBoard,
            rules,
            visited
          );

          nextCaptures.forEach(nextCapture => {
            captures.push({
              from: piece.position,
              to: nextCapture.to,
              captures: [capturedPiece.position, ...(nextCapture.captures || [])]
            });
          });
        }
      }
    }

    return captures;
  }

  static getValidMoves(
    piece: Piece,
    board: Board,
    variant: string
  ): Move[] {
    const rules = GAME_VARIANTS[variant];
    if (!rules) throw new Error('Invalid game variant');

    // First check for captures as they are mandatory
    const captures = this.findCaptures(piece, board, rules);
    if (rules.mandatoryCapture && captures.length > 0) {
      if (rules.maxCaptureSequence) {
        // Return only the captures with maximum number of pieces captured
        const maxCaptures = Math.max(...captures.map(m => m.captures?.length || 0));
        return captures.filter(m => (m.captures?.length || 0) === maxCaptures);
      }
      return captures;
    }

    // If no captures are available or not mandatory, look for regular moves
    const moves: Move[] = [];
    const directions = rules.manBackwardMoves || piece.type === 'king' ? [1, -1] : piece.color === 'black' ? [1] : [-1];

    for (const dy of directions) {
      for (const dx of [-1, 1]) {
        const newX = piece.position.x + dx;
        const newY = piece.position.y + dy;
        const newPos = { x: newX, y: newY };

        if (!this.isValidPosition(newPos, board.size)) continue;

        const isOccupied = board.pieces.some(p => 
          p.position.x === newPos.x && p.position.y === newPos.y
        );
        if (isOccupied) continue;

        if (this.isMoveInDirection(piece.position, newPos, rules, piece)) {
          moves.push({
            from: { ...piece.position },
            to: newPos
          });
        }

        // For flying kings, add long-range moves
        if (piece.type === 'king' && rules.flyingKings) {
          let distance = 2;
          while (true) {
            const longX = piece.position.x + dx * distance;
            const longY = piece.position.y + dy * distance;
            const longPos = { x: longX, y: longY };

            if (!this.isValidPosition(longPos, board.size)) break;

            const isOccupied = board.pieces.some(p => 
              p.position.x === longPos.x && p.position.y === longPos.y
            );
            if (isOccupied) break;

            moves.push({
              from: { ...piece.position },
              to: longPos
            });

            distance++;
          }
        }
      }
    }

    return moves;
  }

  static isKingPosition(position: Position, color: 'black' | 'white', boardSize: number): boolean {
    return color === 'black' ? position.y === boardSize - 1 : position.y === 0;
  }

  static getInitialBoard(variant: string): Board {
    const rules = GAME_VARIANTS[variant];
    if (!rules) throw new Error('Invalid game variant');

    const board: Board = {
      size: rules.boardSize,
      pieces: []
    };

    const rows = Math.floor(rules.piecesPerPlayer / (rules.boardSize / 2));

    // Place black pieces
    for (let y = 0; y < rows; y++) {
      for (let x = 0; x < rules.boardSize; x++) {
        if ((x + y) % 2 === 1) {
          board.pieces.push({
            type: 'man',
            color: 'black',
            position: { x, y }
          });
        }
      }
    }

    // Place white pieces
    for (let y = rules.boardSize - 1; y > rules.boardSize - 1 - rows; y--) {
      for (let x = 0; x < rules.boardSize; x++) {
        if ((x + y) % 2 === 1) {
          board.pieces.push({
            type: 'man',
            color: 'white',
            position: { x, y }
          });
        }
      }
    }

    return board;
  }

  static isValidMove(board: Board, move: Move, variant: string): boolean {
    // Simplified validation - in production this would be more comprehensive
    const rules = GAME_VARIANTS[variant];
    if (!rules) return false;

    // Check if positions are valid
    if (!this.isValidPosition(move.from, board.size) || !this.isValidPosition(move.to, board.size)) {
      return false;
    }

    // Find the piece at the from position
    const piece = board.pieces.find(p => p.position.x === move.from.x && p.position.y === move.from.y);
    if (!piece) return false;

    // Check if the to position is empty
    const targetPiece = board.pieces.find(p => p.position.x === move.to.x && p.position.y === move.to.y);
    if (targetPiece) return false;

    // Basic diagonal movement check
    const dx = Math.abs(move.to.x - move.from.x);
    const dy = Math.abs(move.to.y - move.from.y);
    
    if (dx !== dy) return false; // Must be diagonal

    // For now, allow moves of 1 or 2 squares (capture)
    return dx === 1 || dx === 2;
  }

  static applyMove(board: Board, move: Move): Board {
    // Create a new board with the move applied
    const newBoard: Board = {
      size: board.size,
      pieces: board.pieces.map(p => ({ ...p, position: { ...p.position } }))
    };

    // Find and move the piece
    const pieceIndex = newBoard.pieces.findIndex(p => 
      p.position.x === move.from.x && p.position.y === move.from.y
    );

    if (pieceIndex !== -1) {
      newBoard.pieces[pieceIndex].position = { ...move.to };

      // Handle captures
      if (move.captures) {
        move.captures.forEach(capturePos => {
          const captureIndex = newBoard.pieces.findIndex(p =>
            p.position.x === capturePos.x && p.position.y === capturePos.y
          );
          if (captureIndex !== -1) {
            newBoard.pieces.splice(captureIndex, 1);
          }
        });
      }

      // Check for king promotion
      const piece = newBoard.pieces[pieceIndex];
      if (piece.type === 'man') {
        if (this.isKingPosition(piece.position, piece.color, board.size)) {
          piece.type = 'king';
        }
      }
    }

    return newBoard;
  }

  static checkGameEnd(board: Board, variant: string): { 
    isGameOver: boolean; 
    winner?: 'black' | 'white' | null; 
    reason?: string 
  } {
    const blackPieces = board.pieces.filter(p => p.color === 'black');
    const whitePieces = board.pieces.filter(p => p.color === 'white');

    // Check if either player has no pieces left
    if (blackPieces.length === 0) {
      return { isGameOver: true, winner: 'white', reason: 'No pieces left' };
    }
    if (whitePieces.length === 0) {
      return { isGameOver: true, winner: 'black', reason: 'No pieces left' };
    }

    // For now, just check piece count - in production would check for valid moves
    return { isGameOver: false };
  }
}