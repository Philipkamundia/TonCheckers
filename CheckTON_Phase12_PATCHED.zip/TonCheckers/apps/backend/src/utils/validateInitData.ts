/**
 * validateInitData.ts — REMOVED
 *
 * Telegram initData validation has been removed from this codebase.
 * Authentication is handled exclusively via TonConnect proof (Ed25519
 * wallet signature), which provides a stronger cryptographic guarantee
 * than Telegram's HMAC initData.
 *
 * Any remaining references to initData in the frontend are for UI
 * context only (e.g. reading the user's Telegram display name) and
 * are NOT used for backend authentication decisions.
 */

export {}; // keep module valid for any stale imports
