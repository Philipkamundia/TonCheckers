import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import compression from 'compression';
import { createServer } from 'http';
import { Server } from 'socket.io';
import { checkDbConnection } from './config/db.js';
import { checkRedisConnection } from './config/redis.js';
import { errorHandler, notFoundHandler } from './middleware/errorHandler.js';
import { rateLimitMiddleware } from './middleware/rateLimit.js';
import { configureRoutes } from './routes/index.js';
import { WebSocketService } from './services/websocket.service.js';
import { DepositDetectionService } from './services/deposit-detection.service.js';
import { GameService } from './services/game.service.js';
import { startTimerCheckJob } from './jobs/gameTimerCheck.js';
import { startMatchmakingScan } from './jobs/matchmakingScan.js';
import { startTreasuryMonitor } from './jobs/treasuryMonitor.js';
import { startTournamentStartCheck } from './jobs/tournamentStartCheck.js';
import { startLeaderboardRebuild } from './jobs/leaderboardRebuild.js';
import { logger } from './utils/logger.js';

const app        = express();
const httpServer = createServer(app);
const PORT       = process.env.PORT || 3001;

const io = new Server(httpServer, {
  cors: {
    origin: process.env.NODE_ENV === 'production'
      ? process.env.FRONTEND_URL
      : ['http://localhost:3000', 'http://localhost:5173'],
    credentials: true,
  },
  pingInterval: 25_000,
  pingTimeout:  20_000,
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors({
  origin: process.env.NODE_ENV === 'production'
    ? process.env.FRONTEND_URL
    : ['http://localhost:3000', 'http://localhost:5173'],
  credentials: true,
}));
app.use(helmet());
app.use(morgan('combined', { stream: { write: (msg: string) => logger.http(msg.trim()) } }));
app.use(compression());
app.use(rateLimitMiddleware);

app.get('/health', async (_req, res) => {
  const [db, redis] = await Promise.all([checkDbConnection(), checkRedisConnection()]);
  const ok = db && redis;
  res.status(ok ? 200 : 503).json({
    ok, db: db ? 'connected' : 'error', redis: redis ? 'connected' : 'error',
    uptime: process.uptime(), timestamp: new Date().toISOString(),
  });
});

configureRoutes(app, io);
app.use(notFoundHandler);
app.use(errorHandler);

httpServer.listen(PORT, async () => {
  logger.info(`🚀 CheckTON backend on port ${PORT}`);

  const recovered = await GameService.recoverCrashedGames();
  if (recovered.length) logger.warn(`Recovered ${recovered.length} crashed games`);

  new WebSocketService(io);

  startTimerCheckJob(io);
  startMatchmakingScan(io);
  startTournamentStartCheck(io);
  startLeaderboardRebuild();

  try {
    await DepositDetectionService.start();
  } catch (err) {
    logger.warn(`Deposit poller: ${(err as Error).message}`);
  }

  startTreasuryMonitor();

  logger.info('✅ All services running');
  logger.info(`  ⏱  Move timer job`);
  logger.info(`  🎯 Matchmaking scan`);
  logger.info(`  🏆 Tournament check`);
  logger.info(`  📊 Leaderboard rebuild`);
  logger.info(`  💰 Deposit poller`);
  logger.info(`  🏦 Treasury monitor`);
});

process.on('SIGTERM', () => {
  DepositDetectionService.stop();
  httpServer.close(() => process.exit(0));
});
