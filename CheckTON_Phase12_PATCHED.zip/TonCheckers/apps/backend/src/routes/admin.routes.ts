import { Router } from 'express';
import { adminController } from '../controllers/admin.controller.js';
import { requireAdmin } from '../middleware/requireAdmin.js';
import { requireAuth } from '../middleware/auth.js';

export const adminRouter = Router();

// Challenge endpoint is public — needed to get the challenge before signing
adminRouter.get('/challenge', adminController.getChallenge);

// All other admin routes require both JWT auth AND treasury wallet signature
adminRouter.use(requireAuth, requireAdmin);

// Summary
adminRouter.get('/summary',                    adminController.getSummary);

// Withdrawal queue
adminRouter.get('/withdrawals/pending',        adminController.getPendingWithdrawals);
adminRouter.post('/withdrawals/:id/approve',   adminController.approveWithdrawal);
adminRouter.post('/withdrawals/:id/reject',    adminController.rejectWithdrawal);

// Treasury health
adminRouter.get('/treasury',                   adminController.getTreasury);

// User management
adminRouter.get('/users',                      adminController.getUsers);
adminRouter.post('/users/:id/ban',             adminController.banUser);
adminRouter.post('/users/:id/unban',           adminController.unbanUser);

// Game log
adminRouter.get('/games',                      adminController.getGameLog);

// Tournament oversight
adminRouter.get('/tournaments',                adminController.getTournaments);

// Fee tracker
adminRouter.get('/fees',                       adminController.getFees);

// Crash log
adminRouter.get('/crashes',                    adminController.getCrashLog);

// Admin bot webhook — receives /start command and sends dashboard link
// POST /api/admin/bot-webhook  (registered with Telegram, no auth)
import { handleAdminBotWebhook } from '../notifications/botService.js';
adminRouter.post('/bot-webhook', async (req, res) => {
  await handleAdminBotWebhook(req.body);
  res.json({ ok: true });
});
