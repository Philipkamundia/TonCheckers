import { z } from 'zod';

// TonConnect proof shape (same for connect and reconnect)
const TonProofSchema = z.object({
  timestamp:  z.number(),
  domain:     z.object({ value: z.string() }),
  signature:  z.string().min(1),
  payload:    z.string().min(1),
  // stateInit is required for public key extraction
  stateInit:  z.string().min(1),
});

// POST /auth/connect — first-time wallet connection
export const ConnectWalletSchema = z.object({
  walletAddress: z.string().min(10).max(100),
  proof:         TonProofSchema,
});

export type ConnectWalletInput = z.infer<typeof ConnectWalletSchema>;

// POST /auth/reconnect — re-auth on app resume (same proof requirement)
export const ReconnectWalletSchema = z.object({
  walletAddress: z.string().min(10).max(100),
  proof:         TonProofSchema,
});

export type ReconnectWalletInput = z.infer<typeof ReconnectWalletSchema>;

// POST /auth/refresh
export const RefreshTokenSchema = z.object({
  refreshToken: z.string().min(10),
});

export type RefreshTokenInput = z.infer<typeof RefreshTokenSchema>;
