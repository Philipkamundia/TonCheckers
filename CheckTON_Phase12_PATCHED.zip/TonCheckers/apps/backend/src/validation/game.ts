import { z } from 'zod';

export const PositionSchema = z.object({
  row: z.number().min(0).max(11), // Support up to 12x12 boards
  col: z.number().min(0).max(11)
});

export const MoveSchema = z.object({
  from: PositionSchema,
  to: PositionSchema
});

export const GameMoveRequestSchema = z.object({
  gameId: z.string().min(1),
  from: PositionSchema,
  to: PositionSchema
});
