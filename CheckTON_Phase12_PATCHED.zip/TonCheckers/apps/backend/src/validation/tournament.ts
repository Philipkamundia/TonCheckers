import { CreateTournamentRequestSchema } from '@ton-checkers/shared';

// Re-export the shared schema for backend use
export const TournamentCreateSchema = CreateTournamentRequestSchema;
export { CreateTournamentRequestSchema };
