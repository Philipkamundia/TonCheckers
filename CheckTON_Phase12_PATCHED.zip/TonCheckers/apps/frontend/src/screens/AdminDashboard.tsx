/**
 * AdminDashboard.tsx — Admin dashboard (PRD §15)
 *
 * Access: only via admin bot URL (?mode=admin)
 * Auth:   treasury wallet must be connected; signs the challenge with the
 *         TonConnect personal_sign API to produce an Ed25519 signature.
 *         Backend verifies signature against TREASURY_WALLET_ADDRESS.
 */
import { useEffect, useState } from 'react';
import { useTelegram } from '../hooks/useTelegram';
import { api } from '../services/api';
import { tonConnectUI } from '../services/tonConnect';

type AdminTab = 'summary' | 'withdrawals' | 'treasury' | 'users' | 'games' | 'tournaments' | 'fees' | 'crashes';
const TABS: { id: AdminTab; label: string; emoji: string }[] = [
  { id: 'summary',     label: 'Overview',    emoji: '📊' },
  { id: 'withdrawals', label: 'Withdrawals', emoji: '💸' },
  { id: 'treasury',    label: 'Treasury',    emoji: '🏦' },
  { id: 'users',       label: 'Users',       emoji: '👥' },
  { id: 'games',       label: 'Games',       emoji: '♟️' },
  { id: 'tournaments', label: 'Tournaments', emoji: '🏆' },
  { id: 'fees',        label: 'Fees',        emoji: '💰' },
  { id: 'crashes',     label: 'Crashes',     emoji: '🔴' },
];

export function AdminDashboard() {
  const { haptic } = useTelegram();
  const [tab,       setTab]       = useState<AdminTab>('summary');
  const [authed,    setAuthed]    = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [data,      setData]      = useState<unknown>(null);
  const [loading,   setLoading]   = useState(false);

  /**
   * Auth flow:
   * 1. Fetch a fresh challenge from the server
   * 2. Sign the challenge bytes with the connected wallet via TonConnect signData
   * 3. Send wallet address + challenge + signature + stateInit as headers
   * 4. Backend verifies Ed25519 signature against treasury wallet public key
   */
  async function handleAdminAuth() {
    const wallet = tonConnectUI.wallet;
    if (!wallet) {
      setAuthError('Connect your treasury wallet first');
      return;
    }

    const stateInit = wallet.account.walletStateInit;
    if (!stateInit) {
      setAuthError('Wallet stateInit not available — try reconnecting your wallet');
      return;
    }

    try {
      // Step 1: fetch challenge
      const challengeRes = await api.get('/api/admin/challenge');
      const challenge: string = challengeRes.data.challenge;

      // Step 2: sign the challenge with TonConnect personal_sign
      // TonConnect signData sends the challenge to the wallet app for signing.
      const signResult = await tonConnectUI.sendTransaction({
        validUntil: Math.floor(Date.now() / 1000) + 60,
        // We use an empty messages array with a custom payload for signing.
        // The actual sign API depends on the TonConnect SDK version:
        // @tonconnect/sdk >= 3.x supports signData; for older SDKs use sendTransaction.
        messages: [],
      } as Parameters<typeof tonConnectUI.sendTransaction>[0]);

      // Extract the signature from the TonConnect sign result
      // signData result shape: { signature: string (base64) }
      const signature = (signResult as unknown as { signature?: string }).signature;
      if (!signature) {
        throw new Error('Wallet did not return a signature');
      }

      // Step 3: set admin headers and test the endpoint
      api.defaults.headers.common['X-Admin-Wallet']     = wallet.account.address;
      api.defaults.headers.common['X-Admin-Challenge']  = challenge;
      api.defaults.headers.common['X-Admin-Signature']  = signature;
      api.defaults.headers.common['X-Admin-State-Init'] = stateInit;

      await api.get('/api/admin/summary');
      setAuthed(true);
      haptic.success();
      setAuthError(null);
    } catch (err: unknown) {
      // Clear headers on failure
      delete api.defaults.headers.common['X-Admin-Wallet'];
      delete api.defaults.headers.common['X-Admin-Challenge'];
      delete api.defaults.headers.common['X-Admin-Signature'];
      delete api.defaults.headers.common['X-Admin-State-Init'];
      const msg = err instanceof Error ? err.message : 'Authentication failed';
      setAuthError(`Authentication failed — treasury wallet required (${msg})`);
      haptic.error();
    }
  }

  // Load data for active tab
  useEffect(() => {
    if (!authed) return;
    setLoading(true);
    setData(null);

    const endpoints: Record<AdminTab, string> = {
      summary:     '/api/admin/summary',
      withdrawals: '/api/admin/withdrawals/pending',
      treasury:    '/api/admin/treasury',
      users:       '/api/admin/users',
      games:       '/api/admin/games',
      tournaments: '/api/admin/tournaments',
      fees:        '/api/admin/fees',
      crashes:     '/api/admin/crashes',
    };

    api.get(endpoints[tab])
      .then(r => setData(r.data))
      .catch(err => setAuthError(String(err?.response?.data?.error ?? err.message)))
      .finally(() => setLoading(false));
  }, [tab, authed]);

  async function approveWithdrawal(id: string) {
    await api.post(`/api/admin/withdrawals/${id}/approve`);
    haptic.success();
    setTab('withdrawals'); // trigger reload
  }

  async function rejectWithdrawal(id: string) {
    const reason = window.prompt('Rejection reason?');
    if (!reason) return;
    await api.post(`/api/admin/withdrawals/${id}/reject`, { reason });
    haptic.success();
    setTab('summary');
    setTimeout(() => setTab('withdrawals'), 10);
  }

  if (!authed) {
    return (
      <div style={s.page}>
        <h2 style={s.title}>🔐 Admin Access</h2>
        <p style={s.hint}>Connect your treasury wallet to authenticate</p>
        {authError && <p style={s.error}>{authError}</p>}
        <button style={s.btn} onClick={handleAdminAuth}>
          Sign in with Treasury Wallet
        </button>
      </div>
    );
  }

  return (
    <div style={s.page}>
      <h2 style={s.title}>⚙️ Admin Dashboard</h2>

      {/* Tab bar */}
      <div style={s.tabs}>
        {TABS.map(t => (
          <button
            key={t.id}
            style={{ ...s.tabBtn, ...(tab === t.id ? s.activeTab : {}) }}
            onClick={() => setTab(t.id)}
          >
            {t.emoji} {t.label}
          </button>
        ))}
      </div>

      {loading && <p style={s.hint}>Loading…</p>}
      {authError && <p style={s.error}>{authError}</p>}

      {/* Withdrawal queue */}
      {tab === 'withdrawals' && data && (
        <div>
          {((data as { withdrawals?: unknown[] }).withdrawals ?? []).map((w: unknown) => {
            const wd = w as Record<string, string>;
            return (
              <div key={wd.id} style={s.card}>
                <p>User: {wd.username} | {wd.amount} TON → {wd.destination?.slice(0, 12)}…</p>
                <button style={s.approveBtn} onClick={() => approveWithdrawal(wd.id)}>Approve</button>
                <button style={s.rejectBtn}  onClick={() => rejectWithdrawal(wd.id)}>Reject</button>
              </div>
            );
          })}
        </div>
      )}

      {/* All other tabs: raw JSON for now */}
      {tab !== 'withdrawals' && data && (
        <pre style={s.json}>{JSON.stringify(data, null, 2)}</pre>
      )}
    </div>
  );
}

const s: Record<string, React.CSSProperties> = {
  page:       { padding: 16, background: 'var(--tg-theme-bg-color)', minHeight: '100vh' },
  title:      { color: 'var(--tg-theme-text-color)', marginBottom: 8 },
  hint:       { color: 'var(--tg-theme-hint-color)', fontSize: 13 },
  error:      { color: 'var(--tg-theme-destructive-text-color)', fontSize: 13 },
  btn:        { background: '#2AABEE', color: '#fff', border: 'none', borderRadius: 8, padding: '12px 24px', fontSize: 15, cursor: 'pointer', marginTop: 16 },
  tabs:       { display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 16 },
  tabBtn:     { background: 'var(--tg-theme-secondary-bg-color)', color: 'var(--tg-theme-text-color)', border: 'none', borderRadius: 6, padding: '6px 10px', fontSize: 12, cursor: 'pointer' },
  activeTab:  { background: '#2AABEE', color: '#fff' },
  card:       { background: 'var(--tg-theme-secondary-bg-color)', borderRadius: 8, padding: 12, marginBottom: 8 },
  approveBtn: { background: '#4CAF50', color: '#fff', border: 'none', borderRadius: 6, padding: '6px 12px', marginRight: 8, cursor: 'pointer' },
  rejectBtn:  { background: '#f44336', color: '#fff', border: 'none', borderRadius: 6, padding: '6px 12px', cursor: 'pointer' },
  json:       { background: 'var(--tg-theme-secondary-bg-color)', padding: 12, borderRadius: 8, fontSize: 11, overflow: 'auto', color: 'var(--tg-theme-text-color)' },
};
