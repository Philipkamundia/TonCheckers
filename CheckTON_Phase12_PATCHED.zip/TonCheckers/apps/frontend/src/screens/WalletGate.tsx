/**
 * WalletGate.tsx — Wallet connection screen
 *
 * PRD §2: Wallet connection is the sole auth method.
 * Auth flow:
 *   1. User connects wallet via TonConnect UI
 *   2. TonConnect proof (Ed25519 signature + stateInit) sent to backend
 *   3. Backend verifies proof cryptographically, returns JWT
 *
 * No Telegram initData is sent to the backend.
 */
import { useState, useEffect } from 'react';
import { useTelegram } from '../hooks/useTelegram';
import { useStore } from '../store';
import { authApi } from '../services/api';
import { tonConnectUI } from '../services/tonConnect';
import { TonConnectButton } from '@tonconnect/ui-react';

export function WalletGate({ onConnected }: { onConnected: () => void }) {
  const { haptic, showMainButton, hideMainButton } = useTelegram();
  const { setUser, setTokens } = useStore();
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState<string | null>(null);
  const [wallet,  setWallet]  = useState(tonConnectUI.wallet);

  useEffect(() => {
    return tonConnectUI.onStatusChange((w) => setWallet(w));
  }, []);

  useEffect(() => {
    if (!wallet) return;
    return showMainButton('Continue', handleAuth, { color: '#2AABEE' });
  }, [wallet]);

  async function handleAuth() {
    if (!wallet) return;
    setLoading(true);
    setError(null);

    const proof = wallet.connectItems?.tonProof;
    if (!proof || proof === 'proof_not_requested') {
      setError('Wallet proof not available. Please disconnect and reconnect your wallet.');
      haptic.error();
      setLoading(false);
      return;
    }

    const address = wallet.account.address;
    const stateInit = wallet.account.walletStateInit;

    if (!stateInit) {
      setError('Wallet stateInit not available. Please try a different wallet.');
      haptic.error();
      setLoading(false);
      return;
    }

    try {
      // Always use /connect — backend upserts the user (create if new, update if returning)
      const res = await authApi.connect({
        walletAddress: address,
        proof: {
          timestamp:  proof.timestamp,
          domain:     proof.domain,
          signature:  proof.signature,
          payload:    proof.payload,
          stateInit,
        },
      });

      setTokens(res.data.accessToken, res.data.refreshToken);
      setUser(res.data.user);
      haptic.success();
      hideMainButton();
      onConnected();
    } catch {
      setError('Connection failed. Please disconnect your wallet and try again.');
      haptic.error();
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={styles.container}>
      <div style={styles.logo}>♟️</div>
      <h1 style={styles.title}>CheckTON</h1>
      <p style={styles.subtitle}>Wager TON. Challenge Opponents. Climb the Ranks.</p>

      <div style={styles.card}>
        <p style={styles.cardText}>Connect your TON wallet to start playing</p>
        <TonConnectButton style={{ margin: '0 auto', display: 'block' }} />
        {wallet && (
          <p style={styles.connectedText}>
            ✅ Wallet connected · {wallet.account.address.slice(0, 8)}...
          </p>
        )}
      </div>

      {error   && <p style={styles.error}>{error}</p>}
      {loading && <p style={styles.loading}>Authenticating…</p>}
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  container:     { display:'flex', flexDirection:'column', alignItems:'center', padding:'40px 24px', minHeight:'100vh', background:'var(--tg-theme-bg-color)' },
  logo:          { fontSize:64, marginBottom:16 },
  title:         { fontSize:32, fontWeight:700, color:'var(--tg-theme-text-color)', margin:0 },
  subtitle:      { fontSize:14, color:'var(--tg-theme-hint-color)', textAlign:'center', marginBottom:32 },
  card:          { background:'var(--tg-theme-secondary-bg-color)', borderRadius:16, padding:24, width:'100%', maxWidth:320 },
  cardText:      { color:'var(--tg-theme-text-color)', textAlign:'center', marginBottom:16 },
  connectedText: { color:'#4CAF50', textAlign:'center', fontSize:13, marginTop:12 },
  error:         { color:'var(--tg-theme-destructive-text-color)', fontSize:13, marginTop:12 },
  loading:       { color:'var(--tg-theme-hint-color)', fontSize:13, marginTop:12 },
};
