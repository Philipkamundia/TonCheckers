/**
 * api.ts — Axios client
 *
 * Authentication is handled exclusively via TonConnect proof (Ed25519).
 * Telegram initData is NOT sent to the backend — it is not used for
 * authentication decisions. The JWT issued after proof verification is
 * the sole credential for all API calls.
 */
import axios from 'axios';

const BASE_URL = import.meta.env.VITE_API_URL ?? 'http://localhost:3001';

export const api = axios.create({ baseURL: BASE_URL, timeout: 10_000 });

// Inject auth token on every request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token');
  if (token) config.headers['Authorization'] = `Bearer ${token}`;
  return config;
});

// Auto-refresh on 401
api.interceptors.response.use(
  res => res,
  async (error) => {
    if (error.response?.status === 401) {
      const refresh = localStorage.getItem('refresh_token');
      if (refresh) {
        try {
          const { data } = await axios.post(`${BASE_URL}/api/auth/refresh`, { refreshToken: refresh });
          localStorage.setItem('access_token', data.accessToken);
          error.config.headers['Authorization'] = `Bearer ${data.accessToken}`;
          return api.request(error.config);
        } catch {
          localStorage.removeItem('access_token');
          localStorage.removeItem('refresh_token');
          window.location.reload();
        }
      }
    }
    return Promise.reject(error);
  },
);

// ─── Auth ─────────────────────────────────────────────────────────────────────
export const authApi = {
  // First-time connection: requires TonConnect proof + stateInit
  connect:   (data: { walletAddress: string; proof: unknown }) =>
               api.post('/api/auth/connect', data),
  // Re-auth on app resume: also requires a fresh TonConnect proof
  reconnect: (data: { walletAddress: string; proof: unknown }) =>
               api.post('/api/auth/reconnect', data),
  me:        () => api.get('/api/auth/me'),
};

// ─── Balance ──────────────────────────────────────────────────────────────────
export const balanceApi = {
  get:         ()                                  => api.get('/api/balance'),
  history:     (page = 1)                          => api.get('/api/balance/history', { params: { page } }),
  depositInit: ()                                  => api.post('/api/balance/deposit/init'),
  withdraw:    (amount: string, destination: string) =>
                 api.post('/api/balance/withdraw', { amount, destination }),
};

// ─── Matchmaking ──────────────────────────────────────────────────────────────
export const matchmakingApi = {
  join:   (stake: string) => api.post('/api/matchmaking/join', { stake }),
  cancel: ()              => api.post('/api/matchmaking/cancel'),
  status: ()              => api.get('/api/matchmaking/status'),
};

// ─── Lobby ────────────────────────────────────────────────────────────────────
export const lobbyApi = {
  cancel: (gameId: string) => api.post(`/api/lobby/${gameId}/cancel`),
};

// ─── Tournaments ──────────────────────────────────────────────────────────────
export const tournamentApi = {
  list:   (status?: string) => api.get('/api/tournaments', { params: { status } }),
  get:    (id: string)      => api.get(`/api/tournaments/${id}`),
  create: (data: unknown)   => api.post('/api/tournaments', data),
  join:   (id: string)      => api.post(`/api/tournaments/${id}/join`),
};

// ─── Leaderboard ──────────────────────────────────────────────────────────────
export const leaderboardApi = {
  get: (sort = 'elo', page = 1) => api.get('/api/leaderboard', { params: { sort, page } }),
  me:  ()                       => api.get('/api/leaderboard/me'),
};
