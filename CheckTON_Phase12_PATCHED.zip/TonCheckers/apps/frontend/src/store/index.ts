import { create } from 'zustand';

interface User {
  id:          string;
  username:    string;
  elo:         number;
  walletAddress: string;
}

interface Balance {
  available: string;
  locked:    string;
  total:     string;
}

interface AppStore {
  user:          User | null;
  balance:       Balance | null;
  accessToken:   string | null;
  activeGameId:  string | null;
  myPlayerNum:   1 | 2 | null;
  pendingLobby:  { gameId: string; stake: string; opponentElo: number } | null;

  setUser:         (user: User | null)    => void;
  setBalance:      (b: Balance | null)    => void;
  setTokens:       (access: string, refresh: string) => void;
  setActiveGame:   (gameId: string | null, playerNum: 1 | 2 | null) => void;
  setPendingLobby: (lobby: AppStore['pendingLobby']) => void;
  logout:          () => void;
}

export const useStore = create<AppStore>((set) => ({
  user:         null,
  balance:      null,
  accessToken:  localStorage.getItem('access_token'),
  activeGameId: null,
  myPlayerNum:  null,
  pendingLobby: null,

  setUser:    (user)           => set({ user }),
  setBalance: (balance)        => set({ balance }),
  setTokens:  (access, refresh) => {
    localStorage.setItem('access_token',  access);
    localStorage.setItem('refresh_token', refresh);
    set({ accessToken: access });
  },
  setActiveGame: (gameId, playerNum) => set({ activeGameId: gameId, myPlayerNum: playerNum }),
  setPendingLobby: (lobby)   => set({ pendingLobby: lobby }),
  logout: () => {
    localStorage.removeItem('access_token');
    localStorage.removeItem('refresh_token');
    set({ user: null, balance: null, accessToken: null, activeGameId: null, myPlayerNum: null });
  },
}));
