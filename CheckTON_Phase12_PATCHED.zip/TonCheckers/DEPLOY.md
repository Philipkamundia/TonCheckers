# CheckTON — Railway Deployment Guide

## Prerequisites
- Railway account (railway.app)
- Telegram bots created via @BotFather:
  - Main bot: @CheckTONBot (for user notifications)
  - Admin bot: @CheckTONAdminBot (private, for admin dashboard)
- TON wallets (hot + cold + treasury/admin)
- TON API key from toncenter.com (optional but recommended for mainnet)

---

## Step 1 — Create Railway Project

1. Go to railway.app → New Project → Deploy from GitHub repo
2. Select your CheckTON repo

Railway will auto-detect `railway.json` and configure the build.

---

## Step 2 — Add Database Services

In your Railway project dashboard:

1. **Add PostgreSQL** → Railway provisions a Postgres instance
   - Note the `DATABASE_URL` — Railway injects it automatically as `${{Postgres.DATABASE_URL}}`

2. **Add Redis** → Railway provisions a Redis instance
   - Note the `REDIS_URL` — Railway injects it as `${{Redis.REDIS_URL}}`

---

## Step 3 — Set Environment Variables

In the backend service → Variables tab, add:

```env
# Database (Railway injects these automatically)
DATABASE_URL=${{Postgres.DATABASE_URL}}
REDIS_URL=${{Redis.REDIS_URL}}

# Server
NODE_ENV=production
PORT=3001

# Auth
JWT_SECRET=<generate: openssl rand -base64 32>
JWT_REFRESH_SECRET=<generate: openssl rand -base64 32>

# Telegram
TELEGRAM_BOT_TOKEN=<from @BotFather /newbot>
ADMIN_BOT_TOKEN=<from @BotFather — second bot for admin>

# TON Network
TON_NETWORK=mainnet
TON_API_KEY=<from toncenter.com>

# Treasury Wallets
HOT_WALLET_ADDRESS=<your hot wallet TON address>
HOT_WALLET_MNEMONIC=<24-word seed phrase — keep secret!>
COLD_WALLET_ADDRESS=<your cold wallet TON address>
TREASURY_WALLET_ADDRESS=<your personal admin wallet — used for admin auth>

# Game Config
MIN_DEPOSIT_TON=0.5
MIN_STAKE_TON=0.1
MAX_DAILY_WITHDRAWAL_TON=100

# Frontend URL (your deployed frontend)
FRONTEND_URL=https://your-frontend-url.com
```

---

## Step 4 — Run Database Migrations

After first deploy, open Railway shell for the backend service:

```bash
npm run migrate
```

This runs all 8 migration files in order. Safe to re-run — idempotent.

---

## Step 5 — Deploy Frontend

Option A — Railway static site:
```bash
cd apps/frontend
npm install
npm run build
# Upload dist/ to Railway static service or Vercel/Netlify
```

Option B — Vercel (recommended for frontend):
```bash
cd apps/frontend
vercel deploy
```

Set environment variables in your frontend host:
```env
VITE_API_URL=https://your-backend.railway.app
VITE_WS_URL=https://your-backend.railway.app
VITE_APP_URL=https://your-frontend.vercel.app
```

---

## Step 6 — Configure Telegram Mini App

1. Open @BotFather → `/myapps` → New App
2. Set Web App URL to your frontend URL
3. The app will open inside Telegram when users tap the bot

---

## Step 7 — Register Admin Bot Webhook

Replace `{ADMIN_BOT_TOKEN}` and `{BACKEND_URL}`:

```bash
curl "https://api.telegram.org/bot{ADMIN_BOT_TOKEN}/setWebhook?url={BACKEND_URL}/api/admin/bot-webhook"
```

Now when admin sends `/start` to the admin bot, they receive a dashboard link.

---

## Step 8 — Verify Deployment

```bash
# Health check
curl https://your-backend.railway.app/health
# Expected: { "ok": true, "db": "connected", "redis": "connected" }
```

---

## Production Checklist

- [ ] `npm run migrate` ran successfully
- [ ] `GET /health` returns `ok: true`
- [ ] Main bot sends deposit confirmation (test with small deposit)
- [ ] Admin bot sends dashboard link on `/start`
- [ ] TON deposit of 1 TON → credited within 60 seconds
- [ ] Withdrawal to connected wallet works
- [ ] SSL certificate active (Railway provides this automatically)
- [ ] `NODE_ENV=production` set
- [ ] All secrets rotated from dev values
- [ ] `HOT_WALLET_MNEMONIC` stored securely (Railway encrypted env vars)

---

## Monitoring

Railway provides:
- Deployment logs in real time
- Metrics (CPU, memory, requests)
- Auto-restart on crash (configured in `railway.json`)

Winston logs are written to `logs/` in production. Errors go to `logs/error.log`.
