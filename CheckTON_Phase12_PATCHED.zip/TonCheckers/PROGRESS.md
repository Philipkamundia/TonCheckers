# CheckTON — Build Progress

## Status: All Phases Complete ✅

- [x] Phase 1  — Scaffold & Database
- [x] Phase 2  — Auth & Wallet Connection
- [x] Phase 3  — Balance & Deposit System
- [x] Phase 4  — Checkers Game Engine
- [x] Phase 5  — WebSocket & Game Rooms
- [x] Phase 6  — Matchmaking & Lobby
- [x] Phase 7  — ELO & Settlement
- [x] Phase 8  — Withdrawal System
- [x] Phase 9  — Tournament Engine
- [x] Phase 10 — Leaderboard & AI Mode
- [x] Phase 11 — Frontend
- [x] Phase 12 — Admin & Polish + Security Hardening

---

## Security Hardening (post-Phase 12 audit)

The following fixes were applied after a full code audit:

**Critical**
- `auth.service.ts` — TonConnect Ed25519 proof now fully verified via public key extracted from `stateInit`. Telegram `initData` removed from authentication entirely.
- `middleware/requireAdmin.ts` — Admin Ed25519 signature verification implemented. Challenge now includes a random nonce. Dev-bypass removed.
- `services/withdrawal.service.ts` — Balance deduction moved inside atomic DB transaction. On-chain confirmation polling added before marking withdrawal `sent`. Daily limit now applied to all withdrawals including large ones.
- `services/tournament.service.ts` — Entry fee deduction moved inside the `BEGIN/COMMIT` block to prevent fee loss on crash.

**High**
- `services/game-timer.service.ts` — `redis.keys()` replaced with a ZSET-based expiry lookup (`ZRANGEBYSCORE`). No more O(N) Redis block.
- `websocket/handlers/gameHandler.ts` — Forced multi-jump continuation enforced server-side. Emits `game.must_continue` when further captures are mandatory.

**Medium / Quality**
- `services/balance.service.ts` — Duplicate `settleGame` and `settleDraw` removed. `SettlementService` is the single authority for game settlement.
- `services/game.service.ts` — Dead `settleWin`/`settleDraw` shims removed.
- `utils/ton-math.ts` — New BigInt-based arithmetic library for TON amounts. Eliminates floating-point drift risk.
- `services/settlement.service.ts` — `calculateWinPayout` now uses `ton-math` integer arithmetic.
- `services/withdrawal.service.ts` — Daily limit arithmetic uses `ton-math`.
- `services/matchmaking.service.ts` — `getAllEntries` uses Redis pipeline (single round-trip for N users).
- `services/withdrawal.service.ts` — Hot wallet keypair cached at module level, not re-derived per withdrawal.
- `frontend/src/services/api.ts` — `initData` header removed. `/verify` renamed `/reconnect` (also requires fresh proof).
- `frontend/src/screens/WalletGate.tsx` — Sends `stateInit` + `proof`; single `/connect` flow.
- `frontend/src/screens/AdminDashboard.tsx` — Real TonConnect signing flow. Dev-bypass string removed.
- `PROGRESS.md` — Updated to reflect actual completion state.

---

## Environment

Node: 20.x | PostgreSQL: 15+ | Redis: 7+ | Stack: TypeScript ESM
