// Game configuration constants
export const GAME_CONFIG = {
  BOARD_SIZE: 8,
  INITIAL_PIECES_PER_PLAYER: 12,
  KING_ROW: {
    RED: 0,
    BLACK: 7
  },
  DISCONNECT_TIMEOUT: 60000, // 60 seconds
  MOVE_TIMEOUT: 300000, // 5 minutes per move
  MAX_MOVES_WITHOUT_CAPTURE: 50, // For draw detection
  REPEATED_POSITION_LIMIT: 3 // For draw by repetition
} as const;

// Stakes configuration (in TON)
export const STAKE_OPTIONS = [
  '0.1',
  '0.5',
  '1',
  '2',
  '5',
  '10',
  '25',
  '50'
] as const;

// ELO rating system
export const ELO_CONFIG = {
  DEFAULT_RATING: 1000,
  K_FACTOR: 32,
  MIN_RATING: 100,
  MAX_RATING: 3000,
  PROVISIONAL_GAMES: 10 // Number of games before rating is considered stable
} as const;

// Matchmaking configuration
export const MATCHMAKING_CONFIG = {
  ELO_RANGE_INITIAL: 100,
  ELO_RANGE_EXPANSION: 50, // Expand by this amount every 10 seconds
  MAX_ELO_RANGE: 500,
  SEARCH_TIMEOUT: 120000, // 2 minutes max search time
  SIMULATION_MIN_TIME: 10000, // 10 seconds minimum search animation
  SIMULATION_MAX_TIME: 30000, // 30 seconds maximum search animation
  VS_SCREEN_DURATION: 5000 // 5 seconds VS screen
} as const;

// Platform fees (in percentage)
export const PLATFORM_FEES = {
  GAME_FEE: 0.05, // 5% of pot
  TOURNAMENT_FEE: 0.10, // 10% of prize pool
  WITHDRAWAL_FEE: 0.01 // 1% of withdrawal amount
} as const;
