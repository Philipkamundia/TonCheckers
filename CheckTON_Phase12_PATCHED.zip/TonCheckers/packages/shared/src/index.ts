// Types
export * from './types/game.js';
export * from './types/player.js';
export * from './types/tournament.js';
export * from './types/wallet.js';
export { 
  TransactionType, 
  TransactionStatus,
  isGameTransaction,
  isTournamentTransaction,
  TRANSACTION_TYPE_MIGRATION_MAP
} from './types/wallet.js';

// Errors
export * from './errors/tournament-errors.js';

// Constants
export * from './constants/game.js';
export * from './constants/ui.js';

// Game Rules (static methods version) - export specific items to avoid conflicts
export { 
  CheckersGameRules,
  GAME_VARIANT_RULES,
  type GameVariantRules
} from './gameRules.js';

// Utils (instance-based version - export with different name to avoid conflict)
export { 
  CheckersGameRules as CheckersGameEngine,
  GAME_VARIANT_RULES as VARIANT_RULES,
  type CheckersBoard,
  type CheckersPiece,
  type GameVariantRules as EngineVariantRules
} from './utils/gameRules.js';

// Other utils
export { formatTON, calculateWinRate, generateId } from './utils/index.js';
