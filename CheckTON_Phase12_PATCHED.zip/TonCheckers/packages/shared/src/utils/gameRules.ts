import { GameVariant, PieceColor, PieceType, Position } from '../types/game.js';

export interface CheckersPiece {
  type: PieceType;
  color: PieceColor;
  position: Position;
}

export interface CheckersBoard {
  size: number;
  pieces: CheckersPiece[];
}

export interface GameVariantRules {
  boardSize: number;
  piecesPerPlayer: number;
  flyingKings: boolean;
  mandatoryCapture: boolean;
  backwardCaptures: boolean;
  manBackwardMoves: boolean;
  chainCaptures: boolean;
  maxCaptureSequence: boolean;
  orthogonalMovement: boolean; // For Turkish variant
}

export const GAME_VARIANT_RULES: Record<GameVariant, GameVariantRules> = {
  [GameVariant.AMERICAN]: {
    boardSize: 8,
    piecesPerPlayer: 12,
    flyingKings: false,
    mandatoryCapture: true,
    backwardCaptures: false, // Men can ONLY capture forward
    manBackwardMoves: false,
    chainCaptures: true,
    maxCaptureSequence: false,
    orthogonalMovement: false
  },
  [GameVariant.RUSSIAN]: {
    boardSize: 8,
    piecesPerPlayer: 12,
    flyingKings: true,
    mandatoryCapture: true, // Must capture if possible
    backwardCaptures: true, // Men can capture backwards
    manBackwardMoves: false,
    chainCaptures: true,
    maxCaptureSequence: true, // Must capture MAXIMUM pieces
    orthogonalMovement: false
  },
  [GameVariant.TURKISH]: {
    boardSize: 8,
    piecesPerPlayer: 16,
    flyingKings: true, // Kings can fly any distance
    mandatoryCapture: true,
    backwardCaptures: true, // Men can capture backwards
    manBackwardMoves: false, // Men can ONLY move forward
    chainCaptures: true,
    maxCaptureSequence: true, // Must capture maximum pieces
    orthogonalMovement: true
  },
  [GameVariant.INTERNATIONAL]: {
    boardSize: 10,
    piecesPerPlayer: 20,
    flyingKings: true,
    mandatoryCapture: true,
    backwardCaptures: true,
    manBackwardMoves: false,
    chainCaptures: true,
    maxCaptureSequence: true, // Must capture maximum pieces
    orthogonalMovement: false
  }
};

export class CheckersGameRules {
  private variant: GameVariant;
  private rules: GameVariantRules;

  constructor(variant: GameVariant) {
    this.variant = variant;
    this.rules = GAME_VARIANT_RULES[variant];
  }

  /**
   * Create initial board for the variant
   */
  public createInitialBoard(): CheckersBoard {
    const board: CheckersBoard = {
      size: this.rules.boardSize,
      pieces: []
    };

    // Calculate how many rows to use for each side
    const rowsNeeded = Math.ceil(this.rules.piecesPerPlayer / (this.rules.boardSize / 2));
    
    // Place RED pieces (player - bottom rows)
    let redPiecesPlaced = 0;
    const redStartRow = this.rules.boardSize - rowsNeeded;
    
    for (let row = redStartRow; row < this.rules.boardSize && redPiecesPlaced < this.rules.piecesPerPlayer; row++) {
      for (let col = 0; col < this.rules.boardSize && redPiecesPlaced < this.rules.piecesPerPlayer; col++) {
        if (this.isPlayableSquare(row, col)) {
          board.pieces.push({
            type: PieceType.REGULAR,
            color: PieceColor.RED,
            position: { row, col }
          });
          redPiecesPlaced++;
        }
      }
    }

    // Place BLACK pieces (opponent - top rows)
    let blackPiecesPlaced = 0;
    
    for (let row = 0; row < rowsNeeded && blackPiecesPlaced < this.rules.piecesPerPlayer; row++) {
      for (let col = 0; col < this.rules.boardSize && blackPiecesPlaced < this.rules.piecesPerPlayer; col++) {
        if (this.isPlayableSquare(row, col)) {
          board.pieces.push({
            type: PieceType.REGULAR,
            color: PieceColor.BLACK,
            position: { row, col }
          });
          blackPiecesPlaced++;
        }
      }
    }

    return board;
  }

  /**
   * Determine if a square is playable (dark squares in checkers)
   */
  private isPlayableSquare(row: number, col: number): boolean {
    if (this.rules.orthogonalMovement) {
      // Turkish variant: all squares are playable
      return true;
    } else {
      // Other variants: only dark squares (alternating pattern)
      return (row + col) % 2 === 1;
    }
  }

  /**
   * Convert board to legacy format for database storage
   */
  public boardToLegacyFormat(board: CheckersBoard): number[][] {
    const legacyBoard: number[][] = Array(board.size).fill(null).map(() => Array(board.size).fill(0));
    
    for (const piece of board.pieces) {
      const { row, col } = piece.position;
      let value = 0;
      
      if (piece.color === PieceColor.RED) {
        value = piece.type === PieceType.KING ? 3 : 1;
      } else if (piece.color === PieceColor.BLACK) {
        value = piece.type === PieceType.KING ? 4 : 2;
      }
      
      legacyBoard[row][col] = value;
    }
    
    return legacyBoard;
  }

  /**
   * Get rules for this variant
   */
  public getRules(): GameVariantRules {
    return { ...this.rules };
  }

  /**
   * Get variant
   */
  public getVariant(): GameVariant {
    return this.variant;
  }
}