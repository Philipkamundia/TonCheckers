import { GameVariant, PieceColor, PieceType, Position, Move } from './types/game.js'

export interface GamePiece {
  type: PieceType
  color: PieceColor
  position: Position
}

export interface GameBoard {
  size: number
  pieces: GamePiece[]
}

export interface GameVariantRules {
  boardSize: number
  piecesPerPlayer: number
  flyingKings: boolean
  mandatoryCapture: boolean
  backwardCaptures: boolean
  manBackwardMoves: boolean
  chainCaptures: boolean
  maxCaptureSequence: boolean
  orthogonalMovement: boolean // For Turkish variant
}

export const GAME_VARIANT_RULES: Record<GameVariant, GameVariantRules> = {
  [GameVariant.AMERICAN]: {
    boardSize: 8,
    piecesPerPlayer: 12,
    flyingKings: false,
    mandatoryCapture: true,
    backwardCaptures: false,
    manBackwardMoves: false,
    chainCaptures: true,
    maxCaptureSequence: false,
    orthogonalMovement: false
  },
  [GameVariant.RUSSIAN]: {
    boardSize: 8,
    piecesPerPlayer: 12,
    flyingKings: true,
    mandatoryCapture: true,
    backwardCaptures: true,
    manBackwardMoves: false,
    chainCaptures: true,
    maxCaptureSequence: false,
    orthogonalMovement: false
  },
  [GameVariant.TURKISH]: {
    boardSize: 8,
    piecesPerPlayer: 16,
    flyingKings: true,
    mandatoryCapture: true,
    backwardCaptures: true,
    manBackwardMoves: false,
    chainCaptures: true,
    maxCaptureSequence: false,
    orthogonalMovement: true
  },
  [GameVariant.INTERNATIONAL]: {
    boardSize: 10,
    piecesPerPlayer: 20,
    flyingKings: true,
    mandatoryCapture: true,
    backwardCaptures: true,
    manBackwardMoves: false,
    chainCaptures: true,
    maxCaptureSequence: false,
    orthogonalMovement: false
  }
}

export class CheckersGameRules {
  static getValidMoves(piece: GamePiece, board: GameBoard, variant: GameVariant): Move[] {
    const rules = GAME_VARIANT_RULES[variant];
    const moves: Move[] = [];

    const isKing = piece.type === PieceType.KING;
    const directions = rules.orthogonalMovement
      ? [
        { x: 0, y: 1 },  // Orthogonal
        { x: 1, y: 0 },
        { x: 0, y: -1 },
        { x: -1, y: 0 }
      ]
      : [
        { x: 1, y: 1 },  // Diagonal
        { x: -1, y: 1 },
        { x: 1, y: -1 },
        { x: -1, y: -1 }
      ];

    // Check each direction
    for (const dir of directions) {
      let row = piece.position.row + dir.x;
      let col = piece.position.col + dir.y;

      // Regular moves
      if (this.isValidPosition(row, col, board.size)) {
        const target = this.getPieceAt(row, col, board);
        if (!target) {
          // Check movement rules
          if (isKing || rules.flyingKings || this.isForwardMove(dir.y, piece.color)) {
            moves.push({ from: piece.position, to: { row, col } });
          }
        }
      }

      // Capture moves
      row += dir.x;
      col += dir.y;
      if (this.isValidPosition(row, col, board.size)) {
        const jumpedPiece = this.getPieceAt(row - dir.x, col - dir.y, board);
        const target = this.getPieceAt(row, col, board);
        if (jumpedPiece &&
          jumpedPiece.color !== piece.color &&
          !target &&
          (isKing || rules.flyingKings || this.isForwardMove(dir.y, piece.color) || rules.backwardCaptures)) {
          moves.push({ from: piece.position, to: { row, col }, capturedPieces: [jumpedPiece.position] });
        }
      }
    }

    return moves;
  }

  private static isValidPosition(row: number, col: number, boardSize: number): boolean {
    return row >= 0 && row < boardSize && col >= 0 && col < boardSize;
  }

  private static getPieceAt(row: number, col: number, board: GameBoard): GamePiece | null {
    return board.pieces.find(p => p.position.row === row && p.position.col === col) || null;
  }

  private static isForwardMove(dy: number, color: PieceColor): boolean {
    return color === PieceColor.RED ? dy > 0 : dy < 0;
  }
}