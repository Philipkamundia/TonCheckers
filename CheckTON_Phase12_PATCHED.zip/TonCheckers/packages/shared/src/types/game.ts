import { z } from 'zod';

// Game variant types
export enum GameVariant {
  AMERICAN = 'american',
  RUSSIAN = 'russian',
  TURKISH = 'turkish',
  INTERNATIONAL = 'international'
}

// Game states
export enum GameState {
  WAITING = 'waiting',
  IN_PROGRESS = 'in_progress',
  FINISHED = 'finished',
  ABANDONED = 'abandoned'
}

// Game result types
export enum GameResult {
  WIN = 'win',
  LOSS = 'loss',
  DRAW = 'draw'
}

// Piece types
export enum PieceType {
  REGULAR = 'regular',
  KING = 'king'
}

export enum PieceColor {
  RED = 'red',
  BLACK = 'black'
}

// Position on the board
export const PositionSchema = z.object({
  row: z.number().min(0).max(7),
  col: z.number().min(0).max(7)
});

export type Position = z.infer<typeof PositionSchema>;

// Game piece
export const GamePieceSchema = z.object({
  id: z.string(),
  type: z.nativeEnum(PieceType),
  color: z.nativeEnum(PieceColor),
  position: PositionSchema
});

export type GamePiece = z.infer<typeof GamePieceSchema>;

// Move
export const MoveSchema = z.object({
  from: PositionSchema,
  to: PositionSchema,
  capturedPieces: z.array(PositionSchema).optional(),
  promotedToKing: z.boolean().optional()
});

export type Move = z.infer<typeof MoveSchema>;

// Game board state
export const GameBoardSchema = z.object({
  pieces: z.array(GamePieceSchema),
  currentPlayer: z.nativeEnum(PieceColor),
  moveHistory: z.array(MoveSchema),
  capturedPieces: z.object({
    red: z.array(GamePieceSchema),
    black: z.array(GamePieceSchema)
  })
});

export type GameBoard = z.infer<typeof GameBoardSchema>;

// Board state alias for compatibility 
export type BoardState = GameBoard;

// Game
export const GameSchema = z.object({
  id: z.string(),
  variant: z.nativeEnum(GameVariant),
  state: z.nativeEnum(GameState),
  stake: z.string(), // TON amount as string
  pot: z.string(), // Total pot as string
  players: z.object({
    red: z.string(), // Player ID
    black: z.string() // Player ID
  }),
  board: GameBoardSchema,
  result: z.nativeEnum(GameResult).optional(),
  winner: z.string().optional(), // Player ID
  createdAt: z.date(),
  updatedAt: z.date(),
  finishedAt: z.date().optional()
});

export type Game = z.infer<typeof GameSchema>;
